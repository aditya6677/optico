<?php

/**** Icon Libraries ****/
function tste_iconpicker_optico_enqueue_icon_libraries(){

	// FontAwesome Library
	if ( !wp_style_is( 'font-awesome', 'registered' ) ) { // If library is not registered
		$fontawesome_css = get_template_directory_uri() . '/libraries/font-awesome/css/font-awesome.min.css';
		if( file_exists( WP_PLUGIN_URL . '/js_composer/libraries/lib/bower/font-awesome/css/font-awesome.min.css') ){
			$fontawesome_css = WP_PLUGIN_URL . '/js_composer/libraries/lib/bower/font-awesome/css/font-awesome.min.css';
		}
		wp_register_style( 'font-awesome', $fontawesome_css );
	}

	// Enqueue FontAwesome library for general use (we are using font awesome on single portfolio page)
	wp_enqueue_style( 'font-awesome' );

	// Stroke Gap Icons
	//wp_enqueue_style( 'sgicon', get_template_directory_uri() . '/libraries/stroke-gap-icons/style.css' );
	
	// Optometrist Icon Library
	wp_enqueue_style( 'ts-optometrist-icons', get_template_directory_uri() . '/libraries/ts-optometrist-icons/font/flaticon.css' );

	// themify
	wp_enqueue_style( 'themify', get_template_directory_uri() . '/libraries/themify-icons/themify-icons.css' );

	// vc_linecons
	if ( !wp_style_is( 'vc_linecons', 'registered' ) ) { // If library is not registered
		$linecons_css    = get_template_directory_uri() . '/libraries/vc-linecons/vc_linecons_icons.min.css';
		$vc_linecons_css = WP_PLUGIN_URL . '/js_composer/libraries/css/lib/vc_linecons/vc_linecons_icons.min.css';
		if( file_exists( $vc_linecons_css ) ){
			$linecons_css = $vc_linecons_css;
		}
		wp_register_style( 'vc_linecons', $linecons_css );
	}

	// vc_openiconic
	if ( !wp_style_is( 'vc_openiconic', 'registered' ) ) { // If library is not registered
		$openiconic_css    = get_template_directory_uri() . '/libraries/vc-open-iconic/css/vc-openiconic.min.css';
		$vc_openiconic_css = WP_PLUGIN_URL . '/js_composer/libraries/css/lib/vc-open-iconic/vc_openiconic.min.css';
		if( file_exists( $vc_openiconic_css ) ){
			$openiconic_css = $vc_openiconic_css;
		}
		wp_register_style( 'vc_openiconic', $openiconic_css );
	}

	// vc_typicons
	if ( !wp_style_is( 'typicons', 'registered' ) ) { // If library is not registered
		$typicons_css    = get_template_directory_uri() . '/libraries/typicons/src/font/typicons.min.css';
		$vc_typicons_css = WP_PLUGIN_URL . '/js_composer/libraries/css/lib/typicons/src/font/typicons.min.css';
		if( file_exists( $vc_typicons_css ) ){
			$typicons_css = $vc_typicons_css;
		}
		wp_register_style( 'vc_typicons', $typicons_css );
	}

	// vc_entypo
	if ( !wp_style_is( 'vc_entypo', 'registered' ) ) { // If library is not registered
		$entypo_css    = get_template_directory_uri() . '/libraries/vc_entypo/vc_entypo.min.css';
		$vc_entypo_css = WP_PLUGIN_URL . '/js_composer/libraries/css/lib/vc_entypo/vc_entypo.min.css';
		if( file_exists( $vc_entypo_css ) ){
			$entypo_css = $vc_entypo_css;
		}
		wp_register_style( 'vc_entypo', $entypo_css );
	}

}
#hook the function to wp_enqueue_scripts
add_action( 'wp_enqueue_scripts', 'tste_iconpicker_optico_enqueue_icon_libraries' );

/**
 *  Admin enqueue scripts and styles
 */
function tste_iconpicker_optico_admin_scripts_styles() {
	
	
	/* ThemeStek Icon Picker - JS files */
	
	// Bootstrap icon picker
	wp_enqueue_script( 'bootstrap', get_template_directory_uri().'/includes/libraries/bootstrap/js/bootstrap.min.js', array( 'jquery' ) );
	
	// iconset-tsoptmicon
	wp_enqueue_script( 'iconset-tsoptmicon', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-tsoptmicon.js', array( 'bootstrap' ) );
	
	// iconset-fontawesome
	wp_enqueue_script( 'iconset-fontawesome', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-fontawesome.js', array( 'bootstrap' ) );
	
	// iconset-linecons
	wp_enqueue_script( 'iconset-linecons', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-linecons.js', array( 'bootstrap' ) );
	
	// iconset-themify
	wp_enqueue_script( 'iconset-themify', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-themify.js', array( 'bootstrap' ) );
	
	// iconset-sgicon
	wp_enqueue_script( 'iconset-sgicon', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-sgicon.js', array( 'bootstrap' ) );
	
	
	// iconset-themify
	//wp_enqueue_script( 'iconset-ts_optico', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/iconset-ts_optico.js', array( 'bootstrap' ) );
	
	
	// Bootstrap icon picker
	wp_enqueue_script( 'bootstrap-iconpicker', get_template_directory_uri().'/includes/libraries/bootstrap-iconpicker/js/bootstrap-iconpicker.js', array( 'bootstrap', 'iconset-fontawesome', 'iconset-linecons', 'iconset-themify', 'iconset-sgicon', 'iconset-tsoptmicon' ) );
	
	
	/* ThemeStek Icon Picker - CSS files */
	
	// Bootstrap icon picker - CSS
	wp_enqueue_style( 'bootstrap-iconpicker', get_template_directory_uri() . '/includes/libraries/bootstrap-iconpicker/css/bootstrap-iconpicker.min.css' );
	
	// iconset-fontawesome
	wp_enqueue_style( 'fontawesome', get_template_directory_uri().'/libraries/font-awesome/css/font-awesome.min.css' );

	// iconset-sgicon
	wp_enqueue_style( 'sgicon', get_template_directory_uri().'/libraries/stroke-gap-icons/style.css' );
	
	
	// iconset-ts_optico
	//wp_enqueue_style( 'ts_optico', get_template_directory_uri().'/libraries/themestek-nutricop-extra-icons/font/flaticon.css' );
	
	// iconset-fontawesome
	wp_enqueue_style( 'vc_linecons', get_template_directory_uri().'/libraries/vc-linecons/vc_linecons_icons.min.css' );
	
	// iconset-themify
	wp_enqueue_style( 'themify', get_template_directory_uri().'/libraries/themify-icons/themify-icons.css' );
	
	
	
	
	
	// ThemeStek admin icons CSS library
	//wp_enqueue_style( 'themestek-admin-icons', get_template_directory_uri() . '/includes/libraries/themestek-admin-icons/css/themestek-admin-icon.css' );
	
	
	// themify
	wp_enqueue_style( 'themify' );
	
}
add_action( 'admin_enqueue_scripts', 'tste_iconpicker_optico_admin_scripts_styles' );

/**** ****/

function themestek_iconpicker_settings_field( $settings, $value ) {
	
	$type = ( !empty($settings['settings']['type']) ) ? $settings['settings']['type'] : 'fontawesome' ;
	
	$return = '<div class="themestek-iconpicker-wrapper">';
	
	$return .= '<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput themestek-iconpicker-input ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />';
	
	
	
	$i_value = explode( ' ', $value );
	if( !empty($i_value[1]) ){
		$i_value = $i_value[1];
	} else {
		$i_value = 'fa-anchor';
	}
	
	
	$return .= '
		<!-- icon picker -->
		<div class="ts-ipicker-selector-w">
			<div class="ts-ipicker-selector">
				<span class="ts-ipicker-selected-icon">
					<i class="' . esc_attr( $value ) . '"></i>
				</span>
				<span class="ts-ipicker-selector-button">
					<i class="fip-fa fa fa-arrow-down"></i>
				</span>
			</div>
			<div class="themestek-iconpicker-list-w" style="display:none;">
				<div id="ts-ipicker-library-' . esc_attr( $type ) . '" class="themestek-iconpicker-list" data-iconset="' . esc_attr( $type ) . '" data-icon="' . esc_attr( $i_value ) . '" role="iconpicker"></div>
			</div>
		</div><!-- .ts-ipicker-selector-w -->
	';
	
	$return .= '</div><!-- .themestek-iconpicker-wrapper -->';
	
	return $return; // New button element
}
vc_add_shortcode_param( 'themestek_iconpicker', 'themestek_iconpicker_settings_field', THEMESTEK_OPTICO_URI . '/vc/themestek_iconpicker/themestek_iconpicker.js');

