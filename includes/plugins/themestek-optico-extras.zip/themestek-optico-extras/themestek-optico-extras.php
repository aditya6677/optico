<?php
/*
 * Plugin Name: ThemeStek Extras for Optico Theme
 * Plugin URI: http://www.themestek.com
 * Description: ThemeStek Plugin for Optico Theme
 * Version: 4.8
 * Author: ThemeStek
 * Author URI: http://www.themestek.com
 * Text Domain: tste
 * Domain Path: /languages
 */
 
 // This plugin is created by ThemeStek. Specially for Optico theme. 2222 333 444

/**
 *  TSTE = ThemeStek Theme Extras
 */
define( 'THEMESTEK_OPTICO_VERSION', '1.0' );
define( 'THEMESTEK_OPTICO_DIR', trailingslashit( dirname( __FILE__ ) ) );
define( 'THEMESTEK_OPTICO_URI', plugins_url( '', __FILE__ ) );

/**
 *  Codestar Framework core files
 */
function tste_optico_cs_framework_init(){
	defined('CS_OPTION'          ) or define('CS_OPTION',           'optico');
	defined('CS_ACTIVE_FRAMEWORK') or define('CS_ACTIVE_FRAMEWORK', true    ); // default true
	defined('CS_ACTIVE_METABOX'  ) or define('CS_ACTIVE_METABOX',   true    ); // default true
	defined('CS_ACTIVE_SHORTCODE') or define('CS_ACTIVE_SHORTCODE', true    ); // default true
	defined('CS_ACTIVE_CUSTOMIZE') or define('CS_ACTIVE_CUSTOMIZE', true    ); // default true
	
	// CS Framework
	include THEMESTEK_OPTICO_DIR.'cs-framework/cs-framework.php';
	
	// VC Section templates
	include THEMESTEK_OPTICO_DIR.'vc-templates/vc-templates-functions.php';
	
	// Make shortcode work in text widget
	add_filter('widget_text', 'do_shortcode', 11);

}
add_action( 'init', 'tste_optico_cs_framework_init', 2 );

if( !function_exists('tste_optico_widget_init') ){
function tste_optico_widget_init(){
	// Widgets
	require THEMESTEK_OPTICO_DIR . 'widgets/contact-widget.php'; // Contact Widget
	require THEMESTEK_OPTICO_DIR . 'widgets/recent-posts-widget.php'; // Recent Posts Widget
	require THEMESTEK_OPTICO_DIR . 'widgets/flicker-widget.php'; // Flicker Widget
	require THEMESTEK_OPTICO_DIR . 'widgets/category-list.php'; // Category/Group List Widget
}
}
add_action( 'widgets_init', 'tste_optico_widget_init' );

/**
 *  Codestar Framework core files
 */
function tste_header_css(){
	echo '
<style>
th#themestek_featured_image, td.themestek_featured_image {
    width: 115px !important;
}
td.themestek_featured_image img{
    max-width: 75px;
	height: auto;
}
</style>
';
}
add_action( 'admin_head', 'tste_header_css' );

add_action( 'plugins_loaded', 'themestek_optico_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function themestek_optico_load_textdomain() {
	load_plugin_textdomain( 'tste', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}

/**
 *  Custom Post Types - With Post Meta Boxes
 */
if( function_exists('vc_map') ){
    require_once THEMESTEK_OPTICO_DIR . 'vc/themestek_attach_image/themestek_attach_image.php';
	require_once THEMESTEK_OPTICO_DIR . 'vc/themestek_iconpicker/themestek_iconpicker.php';
	require_once THEMESTEK_OPTICO_DIR . 'vc/themestek_imgselector/themestek_imgselector.php';
	require_once THEMESTEK_OPTICO_DIR . 'vc/themestek_css_editor/themestek_css_editor.php';
}
if( file_exists( get_template_directory() . '/includes/core.php' ) ){
	require_once get_template_directory() . '/includes/core.php';
} else {
	require_once THEMESTEK_OPTICO_DIR . 'core.php';
}
require_once THEMESTEK_OPTICO_DIR . 'custom-post-types/ts-portfolio.php';
require_once THEMESTEK_OPTICO_DIR . 'custom-post-types/ts-team.php';
require_once THEMESTEK_OPTICO_DIR . 'custom-post-types/ts-testimonial.php';
require_once THEMESTEK_OPTICO_DIR . 'custom-post-types/ts-client.php';

/**
 *  Shortcodes
 */
require_once THEMESTEK_OPTICO_DIR . 'shortcodes.php';

/**
 *  Demo content setup
 */
require_once THEMESTEK_OPTICO_DIR . 'demo-content-setup/demo-content-setup.php';

function tste_rewrite_flush() {
    // ATTENTION: This is *only* done during plugin activation hook
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'tste_rewrite_flush' );

/**
 * Enqueue scripts and styles
 */
if( !function_exists('tste_optico_scripts_styles') ){
function tste_optico_scripts_styles() {
	wp_enqueue_script( 'jquery-resize', THEMESTEK_OPTICO_URI . '/js/jquery-resize.min.js', array( 'jquery' ) );
	
	// PrettyPhoto
	if ( wp_script_is( 'prettyphoto', 'registered' ) ) {
		wp_deregister_script( 'prettyphoto' );
	}
	wp_enqueue_script( 'prettyphoto', get_template_directory_uri() . '/libraries/prettyphoto/js/jquery.prettyPhoto.js', array('jquery') , '', true);
	
}
}
add_action( 'wp_enqueue_scripts', 'tste_optico_scripts_styles' );

/**
 * Admin Enqueue scripts and styles
 */
function tste_optico_admin_scripts_styles(){
	wp_register_script( 'tste-optico-vc-templates', THEMESTEK_OPTICO_URI . '/vc-templates/ts-custom-vc-templates.js' , array( 'jquery' ) );
	wp_register_style( 'tste-optico-style', THEMESTEK_OPTICO_URI . '/css/tmte-style.css' );
	
	wp_localize_script( 'tste-optico-vc-templates', 'THEMESTEK_OPTICO_URI',
		esc_url( THEMESTEK_OPTICO_URI )
	);
	wp_localize_script( 'tste-optico-vc-templates', 'THEMESTEK_OPTICO_DIR',
		esc_html( THEMESTEK_OPTICO_DIR )
	);

	wp_enqueue_script( 'tste-optico-vc-templates' );
	wp_enqueue_style( 'tste-optico-style' );
}
add_action( 'admin_enqueue_scripts', 'tste_optico_admin_scripts_styles' );

/**
 * @param $param_value
 * @param string $prefix
 *
 * @since 4.2
 * @return string
 */
if( !function_exists('ts_vc_shortcode_custom_css_class') ){
function ts_vc_shortcode_custom_css_class( $param_value, $prefix = '' ) {
	$css_class = preg_match( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', $param_value ) ? $prefix . preg_replace( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', '$1', $param_value ) : '';
	return $css_class;
}
}

/**
 *  This function will do encoding things. The encode function is not allowed in theme so we created function in plugin
 */
if( !function_exists('themestek_enc_data') ){
function themestek_enc_data( $htmldata='' ) {
	return base64_encode($htmldata);
}
}

/**
 *  URL Encode
 */
if( !function_exists('themestek_url_encode') ){
function themestek_url_encode( $url='' ) {
	return urlencode($url);
}
}

/************** Start Plugin Options settings ************************/

/**
 *  This will create option link and option page
 */
if( !function_exists('tste_optico_register_options_page') ){
function tste_optico_register_options_page() {
	add_options_page(
		esc_html__('Optico Extra Options', 'tste'),  // Page title in TITLE tag
		esc_html__('Optico Extra Options', 'tste'),  // heading on page
		'manage_options',
		'tste-optico',
		'tste_optico_options_page'
	);
}
}
add_action('admin_menu', 'tste_optico_register_options_page');

/**
 *  Save plugin options
 */
if( !function_exists('tste_optico_register_settings') ){
function tste_optico_register_settings() {
	
	// Social share for Blog
	register_setting( 'tste_optico_options_group', 'tste_optico_social_share_blog', 'tste_optico_social_share_blog_callback' );
	//add_option( 'tste_optico_option_name', 'This is my option value.');
	
	// Social share for Portfolio
	register_setting( 'tste_optico_options_group', 'tste_optico_social_share_portfolio', 'tste_optico_social_share_portfolio_callback' );
	//add_option( 'tste_optico_option_name', 'This is my option value.');
	
}
}
add_action( 'admin_init', 'tste_optico_register_settings' );

if( !function_exists('tste_optico_social_share_blog_callback') ){
function tste_optico_social_share_blog_callback( $data ){
	// Save settings to theme options so we can re-use it
	$optico_toptions = get_option('optico_theme_options');
	if( !empty($optico_toptions['post_social_share_services']) ){
		$optico_toptions['post_social_share_services'] = $data;
		update_option('optico_theme_options', $optico_toptions);
	}
	return $data;
}
}

if( !function_exists('tste_optico_social_share_portfolio_callback') ){
function tste_optico_social_share_portfolio_callback( $data ){
	// Save settings to theme options so we can re-use it
	$optico_toptions = get_option('optico_theme_options');
	if( !empty($optico_toptions['portfolio_social_share_services']) ){
		$optico_toptions['portfolio_social_share_services'] = $data;
		update_option('optico_theme_options', $optico_toptions);
	}
	return $data;
}
}

if( !function_exists('tste_optico_options_page') ){
function tste_optico_options_page(){
	
	// Commong elements
	$optico_toptions	= get_option('optico_theme_options');
	$social_list	= array(
						'Facebook'		=> 'facebook',
						'Twitter'		=> 'twitter',
						'Google Plus'	=> 'gplus',
						'Pinterest'		=> 'pinterest',
						'LinkedIn'		=> 'linkedin',
						'Stumbleupon'	=> 'stumbleupon',
						'Tumblr'		=> 'tumblr',
						'Reddit'		=> 'reddit',
						'Digg'			=> 'digg',
					);
	
	?>
	<div class="wrap"> 
		<?php screen_icon(); ?>
		<h1>Optico Extra Options</h1>
		
		<form method="post" action="options.php">
		
			<?php settings_fields( 'tste_optico_options_group' ); ?>

			<p>This page will set some extra options for Optico theme. So it will be stored even when you change theme.</p>
			<br><br>
			
			<h2>Select Social Share Service (for single Post or Portfolio)</h2>
			<p>The selected social service icon will be visible on single view so user can share on social sites.</p>
			<table class="form-table">
				<tr valign="top">
					<th scope="row"><label for="tste_optico_option_name"> Select Social Share Service for Blog Section </label></th>
					<td>
						<p>
						
						<?php
						
						// Getting from Theme Options
						$tste_optico_social_share_blog = array();
						if( !empty($optico_toptions['post_social_share_services']) ){
							$tste_optico_social_share_blog = $optico_toptions['post_social_share_services'];
							
						}
						
						// Now setting checkboxes in Plugin Options
						foreach( $social_list as $social_name=>$social_slug ){
							$checked = '';
							if( is_array($tste_optico_social_share_blog) && in_array( $social_slug, $tste_optico_social_share_blog ) ){
								$checked = 'checked="checked"';
							}
							echo '<label><input name="tste_optico_social_share_blog[]" type="checkbox" value="'.$social_slug.'" '.$checked.'> ' . $social_name . '</label> <br/>';
						}
						
						?>
						
						</p>
					</td>
				</tr>
				
				<!-- ---------- -->
				<tr valign="top">
					<th scope="row"><label for="tste_optico_option_name"> Select Social Share Service for Portfolio Section </label></th>
					<td>
						<p>
						
						<?php
						
						// Getting from Theme Options
						$tste_optico_social_share_portfolio = array();
						if( !empty($optico_toptions['portfolio_social_share_services']) ){
							$tste_optico_social_share_portfolio = $optico_toptions['portfolio_social_share_services'];
							
						}
						
						// Now setting checkboxes in Plugin Options
						foreach( $social_list as $social_name=>$social_slug ){
							$checked = '';
							if( is_array($tste_optico_social_share_portfolio) && in_array( $social_slug, $tste_optico_social_share_portfolio ) ){
								$checked = 'checked="checked"';
							}
							echo '<label><input name="tste_optico_social_share_portfolio[]" type="checkbox" value="'.$social_slug.'" '.$checked.'> ' . $social_name . '</label> <br/>';
						}
						
						?>
						
						</p>
					</td>
				</tr>
				
			</table>
			<?php  submit_button(); ?>
		</form>
		
	</div>
	<?php
}
}

/*******
 *  Social Share links creations
 */
if ( !function_exists( 'themestek_social_share_links' ) ){
function themestek_social_share_links( $post_type='portfolio' ){
	$post_type = esc_attr($post_type);
	
	if( !empty($post_type) ){
		
		$post_type = esc_attr($post_type);
		
		${ $post_type.'_social_share_services' } = themestek_get_option( $post_type.'_social_share_services' );
		
		$return = '';
		
		if( !empty( ${ $post_type.'_social_share_services' } ) && is_array( ${$post_type.'_social_share_services'} ) && count( ${$post_type.'_social_share_services'} > 0 ) ){
			foreach( ${$post_type.'_social_share_services'} as $social ){
				
				switch($social){
					case 'facebook':
						$link = '//web.facebook.com/sharer/sharer.php?u='.urlencode(get_permalink()). '&_rdr';
						break;
						
					case 'twitter':
						$link = '//twitter.com/share?url='. get_permalink();
						break;
					
					case 'gplus':
						$link = '//plus.google.com/share?url='. get_permalink();
						break;
					
					case 'pinterest':
						$link = '//www.pinterest.com/pin/create/button/?url='. get_permalink();
						break;
						
					case 'linkedin':
						$link = '//www.linkedin.com/shareArticle?mini=true&url='. get_permalink();
						break;
						
					case 'stumbleupon':
						$link = '//stumbleupon.com/submit?url='. get_permalink();
						break;
					
					case 'tumblr':
						$link = '//tumblr.com/share/link?url='. get_permalink();
						break;
						
					case 'reddit':
						$link = '//reddit.com/submit?url='. get_permalink();
						break;
						
					case 'digg':
						$link = '//www.digg.com/submit?url='. get_permalink();
						break;
						
				} // switch end here
				
				// Now preparing the icon
				$return .= '<li class="ts-social-share ts-social-share-'. $social .'">
				<a href="javascript:void(0)" onClick="TSSocialWindow=window.open(\''. esc_url($link) .'\',\'TSSocialWindow\',width=600,height=100); return false;"><i class="ts-optico-icon-'. sanitize_html_class($social) .'"></i></a>
				</li>';
				
			}  // foreach
			
		} // if
		
		// preparing final output
		if( $return != '' ){
			$return = '<div class="ts-social-share-links"><ul>'. $return .'</ul></div>';
		}
		
	}
	
	// return data
	return $return;
	
}
}

// Show Featured image in the admin section
add_filter( 'manage_post_posts_columns', 'themestek_post_set_featured_image_column' );
add_action( 'manage_post_posts_custom_column' , 'themestek_post_set_featured_image_column_content', 10, 2 );
if ( ! function_exists( 'themestek_post_set_featured_image_column' ) ) {
function themestek_post_set_featured_image_column($columns) {
	$new_columns = array();
	foreach( $columns as $key=>$val ){
		$new_columns[$key] = $val;
		if( $key=='title' ){
			$new_columns['themestek_featured_image'] = esc_html__( 'Featured Image', 'optico' );
		}
	}
	return $new_columns;
}
}
if ( ! function_exists( 'themestek_post_set_featured_image_column_content' ) ) {
function themestek_post_set_featured_image_column_content( $column, $post_id ) {
	if( $column == 'themestek_featured_image' ){
		if ( has_post_thumbnail($post_id) ) {
			the_post_thumbnail('thumbnail');
		} else {
			echo '<img style="max-width:75px;height:auto;" src="' . THEMESTEK_OPTICO_URI . '/images/admin-no-image.png" />';
		}
	}
}
}

if( !function_exists('themestek_author_socials') ){
function themestek_author_socials( $contactsethods ) {
	$contactsethods['twitter']  = esc_html__( 'Twitter Link', 'optico' );  // Add Twitter
	$contactsethods['facebook'] = esc_html__( 'Facebook Link', 'optico' );  //add Facebook
	$contactsethods['linkedin'] = esc_html__( 'LinkedIn Link', 'optico' );  //add LinkedIn
	$contactsethods['gplus']    = esc_html__( 'Google Plus Link', 'optico' );  //add Google Plus
	return $contactsethods;
}
}
add_filter('user_contactmethods','themestek_author_socials', 20);

/**
 *  Login page logo link
 */
if( !function_exists('ts_loginpage_custom_link') ){
function ts_loginpage_custom_link() {
	return esc_url( home_url( '/' ) );
}
}
add_filter('login_headerurl','ts_loginpage_custom_link');

/**
 * Login page logo link title
 */
if( !function_exists('ts_change_title_on_logo') ){
function ts_change_title_on_logo() {
	return esc_attr( get_bloginfo( 'name', 'display' ) );
}
}
add_filter('login_headertext', 'ts_change_title_on_logo');

/**
 *  add skincolor class style
 */
add_action( 'admin_head', 'themestek_admin_skincolor_css' );
function themestek_admin_skincolor_css(){
	global $optico_theme_options;
	
	$skincolor_default = '#7fc540';  //change this with default skin color
	
	$skincolor = (!empty($optico_theme_options['skincolor'])) ? $optico_theme_options['skincolor'] : $skincolor_default ;
	
	?>
	<style>
	
		.cs-framework.cs-option-framework .button:not(.wp-color-result):not(.ed_button){
			width: auto !important;
			text-shadow: none !important;
			box-shadow: none !important;
			color: #ffffff !important;
			border: none;
		}
		.cs-framework.cs-option-framework .button.button-primary:not(.wp-color-result):not(.ed_button){
			width: auto !important;
			text-shadow: none !important;
			box-shadow: none !important;
			color: #fff !important;
			border: none;
		}
		.cs-framework.cs-option-framework .button span.wp-media-buttons-icon:before{
			color: inherit;
		}
	
		.ts_vc_colored-dropdown .skincolor,
		.vc_colored-dropdown .skincolor,
		.vc_btn3.vc_btn3-color-skincolor{  /* VC button */
			background-color: <?php echo esc_html($skincolor); ?> !important;
			color: #fff !important;
		}
		.vc_btn3.vc_btn3-color-skincolor.vc_btn3-style-outline{
			color: <?php echo esc_html($skincolor); ?> !important;
			border-color: <?php echo esc_html($skincolor); ?> !important;
			background-color: transparent !important;
		}
		.vc_btn3.vc_btn3-color-skincolor.vc_btn3-style-3d {
			box-shadow: 0 4px rgba(<?php echo themestek_hex2rgb($skincolor); ?>, 0.73), 0 4px rgb(0, 0, 0) !important;
		}
		
		.vc_btn3.vc_btn3-style-text.vc_btn3-color-skincolor{ /* Normal Text style button */
			color: <?php echo esc_html($skincolor); ?> !important;
			background-color: transparent !important;
		}
		
		/* VC Templates - Section template box style */
		body .vc_ui-panel-header-container,
		.ts_vc_filters .cz_active,
		
		/* VC editor - in post page etc */
		.composer-switch,
		/*.composer-switch .logo-icon,
		.composer-switch a, .composer-switch a:visited,
		.composer-switch a.wpb_switch-to-front-composer, .composer-switch a:visited.wpb_switch-to-front-composer,*/
		.vc_navbar,
		.wp-pointer-content h3,
		
		/* VC Editor - new page message buttons */
		.vc_ui-button.vc_ui-button-info,
		
		/* Theme Options - buttons */
		.cs-framework .button:not(.wp-color-result):not(.ed_button) {
			background-color: <?php echo ts_adjustBrightness($skincolor, '-25'); ?> !important;
		}
		
		/*** VC Message Box - Border Color - Skincolor ***/
		.wp-pointer-content h3{
			border-color: <?php echo ts_adjustBrightness($skincolor, '-25'); ?> !important;
		}
		
		/*** VC Message Box - Icon Color - Skincolor ***/
		.wp-pointer-content h3:before{
			color: <?php echo ts_adjustBrightness($skincolor, '-25'); ?> !important;
		}
		
		.composer-switch .logo-icon,
		.composer-switch a, .composer-switch a:visited,
		.composer-switch a.wpb_switch-to-front-composer, .composer-switch a:visited.wpb_switch-to-front-composer {
			background-color: transparent !important;
		}
		.vc_navbar .vc_icon-btn:hover,
		.composer-switch a.wpb_switch-to-composer:hover,
		.composer-switch a:visited.wpb_switch-to-composer:hover,
		.composer-switch a.wpb_switch-to-front-composer:hover,
		.composer-switch a:visited.wpb_switch-to-front-composer:hover {
			background-color: rgba(255, 255, 255, 0.27) !important;
		}
		#wpb_visual_composer .vc_navbar{
			border-bottom: none !important;
		}
		
		/* VC - ThemeStek tab on instert element */
		.ts-tab-main {
			font-weight: bold !important;
		}
		
		.cs-framework .button.button-primary:not(.wp-color-result):not(.ed_button) {
			background-color: <?php echo ts_adjustBrightness($skincolor, '-75'); ?> !important;
		}
		
	</style>
	
	<script>
	jQuery( document ).ready(function($) {
		$( "button:contains('THEMESTEK')" ).addClass('ts-tab-main');
	});
	</script>
	
	<?php
	
}

if( !function_exists('ts_adjustBrightness') ){
function ts_adjustBrightness($hex, $steps) {
    // Steps should be between -255 and 255. Negative = darker, positive = lighter
    $steps = max(-255, min(255, $steps));

    // Format the hex color string
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
    }

    // Get decimal values
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));

    // Adjust number of steps and keep it inside 0 to 255
    $r = max(0,min(255,$r + $steps));
    $g = max(0,min(255,$g + $steps));  
    $b = max(0,min(255,$b + $steps));

    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);

    return '#'.$r_hex.$g_hex.$b_hex;
}
}

/**
 *  Create New Param Type : Info
 */
if( function_exists('vc_add_shortcode_param') ){
	vc_add_shortcode_param( 'themestek_info', 'themestek_vc_param_info' );
	function themestek_vc_param_info( $settings, $value ) {
		$return  = '';
		$head    = ( !empty($settings['head']) ) ? '<h2 class="ts_vc_info_heading">'.$settings['head'].'</h2>' : '' ;
		$subhead = ( !empty($settings['subhead']) ) ? '<h4 class="ts_vc_info_subheading">'.$settings['subhead'].'</h4>' : '' ;
		$desc    = ( !empty($settings['desc']) ) ? '<div class="ts_vc_info_desc">'.$settings['desc'].'</div>' : '' ;
		
		$return .= '<div class="themestek_vc_param_info '.$settings['param_name'].'">'
					. '<div class="themestek_vc_param_info_inner">'
						. $head
						. $subhead
						. $desc 
					. '</div>'
			   . '</div>'; // This is html markup that will be outputted in content elements edit form
	   return $return;
	}
}

/*************** theme-style.css generator *******************/





function themestek_theme_css() {
	$optico_theme_options = get_option('optico_theme_options');
	
	header("Content-Type: text/css");
	ob_start();
	include get_template_directory().'/css/theme-style.php'; // Fetching theme-style.php output and store in a variable
	$css    = ob_get_clean();
	
	// Minify CSS style
	if( isset( $optico_theme_options['minify'] ) && esc_attr($optico_theme_options['minify'])==true && function_exists('themestek_minify_css') ){
		$css = themestek_minify_css( $css );
	}
	
	// output
	echo $css;
	
	exit;
}
add_action('wp_ajax_themestek_theme_css', 'themestek_theme_css');
add_action('wp_ajax_nopriv_themestek_theme_css', 'themestek_theme_css');

/**
 * Ajax call for dynamic css file
 */
function tmte_load_dynamic_style(){
	$skincolor = '';
	if( is_page() || is_singular() ){
		$themestek_metabox_group = get_post_meta( get_the_ID(), '_themestek_metabox_group', true ); // fetching all post meta
		if( !empty($themestek_metabox_group['skincolor']) ){
			$skincolor = '&color=' . str_replace('#', '', $themestek_metabox_group['skincolor'] );
		}
	}
	wp_enqueue_style('tste-optico-theme-style', admin_url('admin-ajax.php').'?action=themestek_theme_css'.$skincolor);
}
add_action( 'wp_enqueue_scripts', 'tmte_load_dynamic_style', 20 );

/**
 *  Remove type attribute from script and style tags
 */
 
function themestek_is_login_page() {
    return in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php'));
}

if( !themestek_is_login_page() && !is_admin() ){

	add_filter('style_loader_tag', 'themestek_remove_type_attr', 10, 2);
	add_filter('script_loader_tag', 'themestek_remove_type_attr', 10, 2);
	
	// remove from all script and style tags
	if( !function_exists('themestek_remove_type_attr') ){
	function themestek_remove_type_attr($tag, $handle) {
		return preg_replace( "/type=['\"]text\/(javascript|css)['\"]/", '', $tag );
	}
	}
	
	// Remove form body content and head content
	add_action('wp_loaded', 'themestek_output_buffer_start');
	function themestek_output_buffer_start() { 
		ob_start("themestek_output_callback"); 
	}
	add_action('shutdown', 'themestek_output_buffer_end');
	function themestek_output_buffer_end() { 
		if (ob_get_contents()){ ob_end_flush(); }
	}
	function themestek_output_callback($buffer) {
		return preg_replace( "%[ ]type=[\'\"]text\/(javascript|css)[\'\"]%", '', $buffer );
	}
	
}

/**
 *  Disabling VC welcome page redirection
 */
function themestek_disable_vc_welcome(){
	delete_transient( '_vc_page_welcome_redirect' );
}
add_action( 'admin_init', 'themestek_disable_vc_welcome', 1 );

/**
 * Register widget areas.
 *
 * @since Optico 1.0
 *
 * @return void
 */
function optico_widgets_init() {
	
	$optico_theme_options = get_option('optico_theme_options');
	
	$pf_type_title_singular     = ( !empty($optico_theme_options['pf_type_title_singular'])    ) ? $optico_theme_options['pf_type_title_singular']    : esc_attr__('Portfolio', 'optico' ) ;
	$pf_cat_title_singular      = ( !empty($optico_theme_options['pf_cat_title_singular'])     ) ? $optico_theme_options['pf_cat_title_singular']     : esc_attr__('Portfolio Category', 'optico' ) ;
	$team_type_title_singular   = ( !empty($optico_theme_options['team_type_title_singular'])  ) ? $optico_theme_options['team_type_title_singular']  : esc_attr__('Team Member', 'optico' ) ;
	$team_group_title_singular  = ( !empty($optico_theme_options['team_group_title_singular']) ) ? $optico_theme_options['team_group_title_singular'] : esc_attr__('Team Group', 'optico' ) ;
	
	register_sidebar( array(
		'name'			=> esc_attr__( 'Left Sidebar for Blog', 'optico' ),
		'id'			=> 'sidebar-left-blog',
		'description'	=> esc_attr__( 'This is left sidebar for blog section', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );

	register_sidebar( array(
		'name'			=> esc_attr__( 'Right Sidebar for Blog', 'optico' ),
		'id'			=> 'sidebar-right-blog',
		'description'	=> esc_attr__( 'This is right sidebar for blog section', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	register_sidebar( array(
		'name'			=> esc_attr__( 'Left Sidebar for Pages', 'optico' ),
		'id'			=> 'sidebar-left-page',
		'description'	=> esc_attr__( 'This is left sidebar for pages', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );

	register_sidebar( array(
		'name'			=> esc_attr__( 'Right Sidebar for Pages', 'optico' ),
		'id'			=> 'sidebar-right-page',
		'description'	=> esc_attr__( 'This is right sidebar for pages', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	// Portfolio - Left
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Left Sidebar for %1$s', 'optico' ), $pf_type_title_singular ),
		'id'			=> 'sidebar-left-portfolio',
		'description'	=> esc_attr__( 'This is left sidebar for Portfolio', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	// Portfolio - Right
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Right Sidebar for %1$s', 'optico' ), $pf_type_title_singular ),
		'id'			=> 'sidebar-right-portfolio',
		'description'	=> esc_attr__( 'This is right sidebar for Portfolio', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	// Portfolio Category - Left
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Left Sidebar for %1$s', 'optico' ), $pf_cat_title_singular ),
		'id'			=> 'sidebar-left-portfoliocat',
		'description'	=> esc_attr__( 'This is left sidebar for Portfolio Category pages.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	// Portfolio Category - Right
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Right Sidebar for %1$s', 'optico' ), $pf_cat_title_singular ),
		'id'			=> 'sidebar-right-portfoliocat',
		'description'	=> esc_attr__( 'This is right sidebar for Portfolio Category pages.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	// Team Member - Left
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Left Sidebar for %1$s', 'optico' ), $team_type_title_singular ),
		'id'			=> 'sidebar-left-team-member',
		'description'	=> esc_attr__( 'This is left sidebar for Team Member', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	// Team Member - Right
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Right Sidebar for %1$s', 'optico' ), $team_type_title_singular ),
		'id'			=> 'sidebar-right-team-member',
		'description'	=> esc_attr__( 'This is right sidebar for Team Member', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	// Team Member Group - Left
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Left Sidebar for %1$s', 'optico' ), $team_group_title_singular ),
		'id'			=> 'sidebar-left-team-member-group',
		'description'	=> esc_attr__( 'This is left sidebar for Team Member Group.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	// Team Member Group - Right
	register_sidebar( array(
		'name'			=> sprintf( esc_attr__( 'Right Sidebar for %1$s', 'optico' ), $team_group_title_singular ),
		'id'			=> 'sidebar-right-team-member-group',
		'description'	=> esc_attr__( 'This is right sidebar for Team Member Group', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	register_sidebar( array(
		'name'			=> esc_attr__( 'Left Sidebar for Search', 'optico' ),
		'id'			=> 'sidebar-left-search',
		'description'	=> esc_attr__( 'This is left sidebar for search', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'Right Sidebar for search', 'optico' ),
		'id'			=> 'sidebar-right-search',
		'description'	=> esc_attr__( 'This is right sidebar for search', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );

	if( function_exists('is_woocommerce') ){
		// WooCommerce - Left
		register_sidebar( array(
			'name' => esc_html__( 'Left Sidebar for WooCommerce Shop Page', 'optico' ),
			'id' => 'sidebar-left-woocommerce',
			'description' => esc_html__( 'This is left sidebar for WooCommerce shop pages.', 'optico' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) );
		// WooCommerce - Right
		register_sidebar( array(
			'name' => esc_html__( 'Right Sidebar for WooCommerce Shop Page', 'optico' ),
			'id' => 'sidebar-right-woocommerce',
			'description' => esc_html__( 'This is right sidebar for WooCommerce shop pages.', 'optico' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) );
	}
	
	// First Footer widgets
	register_sidebar( array(
		'name'			=> esc_attr__( 'First Footer - 1st Column', 'optico' ),
		'id'			=> 'first-footer-1-widget-area',
		'description'	=> esc_attr__( 'This is first footer widget area for first row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'First Footer - 2nd Column', 'optico' ),
		'id'			=> 'first-footer-2-widget-area',
		'description'	=> esc_attr__( 'This is second footer widget area for first row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'First Footer - 3rd Column', 'optico' ),
		'id'			=> 'first-footer-3-widget-area',
		'description'	=> esc_attr__( 'This is third footer widget area for first row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'First Footer - 4th Column', 'optico' ),
		'id'			=> 'first-footer-4-widget-area',
		'description'	=> esc_attr__( 'This is fourth footer widget area for first row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	// Second Footer widgets
	register_sidebar( array(
		'name'			=> esc_attr__( 'Second Footer - 1st Column', 'optico' ),
		'id'			=> 'second-footer-1-widget-area',
		'description'	=> esc_attr__( 'This is first footer widget area for second row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'Second Footer - 2nd Column', 'optico' ),
		'id'			=> 'second-footer-2-widget-area',
		'description'	=> esc_attr__( 'This is second footer widget area for second row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'Second Footer - 3rd Column', 'optico' ),
		'id'			=> 'second-footer-3-widget-area',
		'description'	=> esc_attr__( 'This is third footer widget area for second row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	register_sidebar( array(
		'name'			=> esc_attr__( 'Second Footer - 4th Column', 'optico' ),
		'id'			=> 'second-footer-4-widget-area',
		'description'	=> esc_attr__( 'This is fourth footer widget area for second row of footer.', 'optico' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	) );
	
	// Dynamic Sidebars (Unlimited Sidebars)
	global $optico_theme_options;
	$optico_theme_options = get_option('optico_theme_options');
	if( isset($optico_theme_options['custom_sidebars']) && is_array($optico_theme_options['custom_sidebars']) && count($optico_theme_options['custom_sidebars'])>0 ){
		foreach( $optico_theme_options['custom_sidebars'] as $custom_sidebar ){
			
			if( isset($custom_sidebar['custom_sidebar']) && trim($custom_sidebar['custom_sidebar'])!='' ){
				$custom_sidebar = $custom_sidebar['custom_sidebar'];
				if( trim($custom_sidebar)!='' ){
					$custom_sidebar_key = sanitize_title($custom_sidebar);
					register_sidebar( array(
						'name'          => $custom_sidebar,
						'id'            => $custom_sidebar_key,
						'description'   => esc_attr__( 'This is custom widget developed from "Optico Options".', 'optico' ),
						'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
						'after_widget'  => '</aside>',
						'before_title'  => '<h3 class="widget-title">',
						'after_title'   => '</h3>',
					) );
				}
			}
			
		}
	}
	
}
add_action( 'widgets_init', 'optico_widgets_init' );

/**
 *  CSS Minifier
 */
if( !function_exists('themestek_minify_css') ){
function themestek_minify_css( $css ){
	if( !empty($css) ){
		// Remove comments
		$css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
		// Remove new line charactor
		$css = str_replace(array("\r\n", "\r", "\n", "\t"), '', $css);
		// Remove whitespace
		$css = str_replace(array('  ', '   ', '    ', '     ', '      ', '       ', '        ', '         ', '          '), ' ', $css);
		// Remove space after colons
		$css = str_replace(': ', ':', $css);
		// Remove space near commas
		$css = str_replace(', ', ',', $css);
		$css = str_replace(' ,', ',', $css);
		// Remove space before brackets
		$css = str_replace('{ ', '{', $css);
		$css = str_replace('} ', '}', $css);
		$css = str_replace(' {', '{', $css);
		$css = str_replace(' }', '}', $css);
		// Remove last dot with comma
		$css = str_replace(';}', '}', $css);
		// Remove whitespace again
		$css = str_replace(array('  ', '   ', '    ', '     ', '      ', '       ', '        ', '         ', '          '), ' ', $css);
		// Remove extra space
		$css = str_replace('; }', ';}', $css);
	}
	return $css;
}
}
