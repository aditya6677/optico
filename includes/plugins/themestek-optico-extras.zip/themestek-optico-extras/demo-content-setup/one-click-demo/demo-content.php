<?php

/******************* Helper Functions ************************/

/**
 *
 * Encode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_encode_string' ) ) {
	function cs_encode_string( $string ) {
		return rtrim( strtr( call_user_func( 'base'. '64' .'_encode', addslashes( gzcompress( serialize( $string ), 9 ) ) ), '+/', '-_' ), '=' );
	}
}

/**
 *
 * Decode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_decode_string' ) ) {
	function cs_decode_string( $string ) {
		return unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
	}
}

/*************** Demo Content Settings *******************/
function themestek_action_rss2_head(){
	// Get theme configuration
	$sidebars = get_option('sidebars_widgets');
	// Get Widgests configuration
	$sidebars_config = array();
	foreach ($sidebars as $sidebar => $widget) {
		if ($widget && is_array($widget)) {
			foreach ($widget as $name) {
				$name = preg_replace('/-\d+$/','',$name);
				$sidebars_config[$name] = get_option('widget_'.$name);
			}
		}
	}
	
	// Get Menus
	$locations = get_nav_menu_locations();
	$menus     = wp_get_nav_menus();
	$menuList  = array();
	foreach( $locations as $location => $menuid ){
		if( $menuid!=0 && $menuid!='' && $menuid!=false ){
			if( is_array($menus) && count($menus)>0 ){
				foreach( $menus as $menu ){
					if( $menu->term_id == $menuid ){
						$menuList[$location] = $menu->name;
					}
				}
			}
		}
	}
	
	$config = array(
			'page_for_posts'   => get_the_title( get_option('page_for_posts') ),
			'show_on_front'    => get_option('show_on_front'),
			'page_on_front'    => get_the_title( get_option('page_on_front') ),
			'posts_per_page'   => get_option('posts_per_page'),
			'sidebars_widgets' => $sidebars,
			'sidebars_config'  => $sidebars_config,
			'menu_list'        => $menuList,
		);            
	if ( defined('THEMESTEK_THEME_DEVELOPMENT') ) {
		echo sprintf('<wp:theme_custom>%s</wp:theme_custom>', base64_encode(serialize($config)));
	}
}

if ( defined('THEMESTEK_THEME_DEVELOPMENT') ) {
	add_action('rss2_head', 'themestek_action_rss2_head');
}

/**********************************************************/

if( !class_exists( 'themestek_optico_one_click_demo_setup' ) ) {

	class themestek_optico_one_click_demo_setup{
		
		
		function __construct(){
			add_action( 'wp_ajax_optico_install_demo_data', array( &$this , 'ajax_install_demo_data' ) );
		}
		
		
		/**
		 * Decide if the given meta key maps to information we will want to import
		 *
		 * @param string $key The meta key to check
		 * @return string|bool The key if we do want to import, false if not
		 */
		function is_valid_meta_key( $key ) {
			// skip attachment metadata since we'll regenerate it from scratch
			// skip _edit_lock as not relevant for import
			if ( in_array( $key, array( '_wp_attached_file', '_wp_attachment_metadata', '_edit_lock' ) ) )
				return false;
			return $key;
		}
		
		
		
		
		/**
		 * Added to http_request_timeout filter to force timeout at 60 seconds during import
		 * @return int 60
		 */
		function bump_request_timeout() {
			return 600;
		}
		
		
		
		/**
		 * Map old author logins to local user IDs based on decisions made
		 * in import options form. Can map to an existing user, create a new user
		 * or falls back to the current user in case of error with either of the previous
		 */
		function get_author_mapping() {
			
			if ( ! isset( $_POST['imported_authors'] ) )
				return;

			$create_users = $this->allow_create_users();

			foreach ( (array) $_POST['imported_authors'] as $i => $old_login ) {
				// Multisite adds strtolower to sanitize_user. Need to sanitize here to stop breakage in process_posts.
				$santized_old_login = sanitize_user( $old_login, true );
				$old_id = isset( $this->authors[$old_login]['author_id'] ) ? intval($this->authors[$old_login]['author_id']) : false;

				if ( ! empty( $_POST['user_map'][$i] ) ) {
					$user = get_userdata( intval($_POST['user_map'][$i]) );
					if ( isset( $user->ID ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user->ID;
						$this->author_mapping[$santized_old_login] = $user->ID;
					}
				} else if ( $create_users ) {
					if ( ! empty($_POST['user_new'][$i]) ) {
						$user_id = wp_create_user( $_POST['user_new'][$i], wp_generate_password() );
					} else if ( $this->version != '1.0' ) {
						$user_data = array(
							'user_login' => $old_login,
							'user_pass' => wp_generate_password(),
							'user_email' => isset( $this->authors[$old_login]['author_email'] ) ? $this->authors[$old_login]['author_email'] : '',
							'display_name' => $this->authors[$old_login]['author_display_name'],
							'first_name' => isset( $this->authors[$old_login]['author_first_name'] ) ? $this->authors[$old_login]['author_first_name'] : '',
							'last_name' => isset( $this->authors[$old_login]['author_last_name'] ) ? $this->authors[$old_login]['author_last_name'] : '',
						);
						$user_id = wp_insert_user( $user_data );
					}

					if ( ! is_wp_error( $user_id ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user_id;
						$this->author_mapping[$santized_old_login] = $user_id;
					} else {
						printf( __( 'Failed to create new user for %s. Their posts will be attributed to the current user.', 'optico-demosetup' ), esc_html($this->authors[$old_login]['author_display_name']) );
						if ( defined('IMPORT_DEBUG') && IMPORT_DEBUG )
							echo ' ' . $user_id->get_error_message();
						echo '<br />';
					}
				}

				// failsafe: if the user_id was invalid, default to the current user
				if ( ! isset( $this->author_mapping[$santized_old_login] ) ) {
					if ( $old_id )
						$this->processed_authors[$old_id] = (int) get_current_user_id();
					$this->author_mapping[$santized_old_login] = (int) get_current_user_id();
				}
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/**
		 * Install demo data
		 **/
		function ajax_install_demo_data() {
		
			// Maximum execution time
			@ini_set('max_execution_time', 60000);
			@set_time_limit(60000);

			define('WP_LOAD_IMPORTERS', true);
			include_once( THEMESTEK_OPTICO_DIR .'demo-content-setup/one-click-demo/wordpress-importer/wordpress-importer.php' );
			$included_files = get_included_files();

			$WP_Import = new themestek_WP_Import;
			
			$WP_Import->fetch_attachments = true;
			
			// Getting layout type
			$layout_type = 'classic';
			
			// getting layout type for correct XML file
			$filename = 'demo.xml';
			
			$WP_Import->import_start( THEMESTEK_OPTICO_DIR .'demo-content-setup/one-click-demo/'.$filename );
			
			
			$_POST     = stripslashes_deep( $_POST );
			$subaction = $_POST['subaction'];
			if( !empty($_POST['layout_type']) ){
				$layout_type = $_POST['layout_type'];
				$layout_type = strtolower($layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
			}
			$data      = isset( $_POST['data'] ) ? unserialize( base64_decode( $_POST['data'] ) ) : array();
			$answer    = array();
			echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
			
			
			switch( $subaction ) {
				
				case( 'start' ):
				
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_cat';
					$answer['message']        = __('Inserting Categories...', 'optico-demosetup');
					$answer['data']           = '';
					$answer['layout_type']	  = $layout_type;
				
					die( json_encode( $answer ) );
				
				break;
				
				
				case( 'install_demo_cat' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_categories();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_tags';
					$answer['message']        = __('All Categories were inserted successfully. Inserting Tags...', 'optico-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_tags' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_tags();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_terms';
					$answer['message']        = __('All Tags were inserted successfully. Inserting Terms...', 'optico-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_terms' ):
					
					wp_suspend_cache_invalidation( true );
					ob_start();
					$WP_Import->process_terms();
					ob_end_clean();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_posts';
					$answer['message']        = __('All Terms were inserted successfully. Inserting Posts...', 'optico-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				case( 'install_demo_posts' ):
					//wp_suspend_cache_invalidation( true );
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					ob_start();
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					$WP_Import->process_posts();
					ob_end_clean();
					//wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_images';
					$answer['message']        = __('All Posts were inserted successfully. Importing images...', 'optico-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					$answer['missing_menu_items']   = base64_encode( serialize( $WP_Import->missing_menu_items ) );
					$answer['processed_terms']      = base64_encode( serialize( $WP_Import->processed_terms ) );
					$answer['processed_posts']      = base64_encode( serialize( $WP_Import->processed_posts ) );
					$answer['processed_menu_items'] = base64_encode( serialize( $WP_Import->processed_menu_items ) );
					$answer['menu_item_orphans']    = base64_encode( serialize( $WP_Import->menu_item_orphans ) );
					$answer['url_remap']            = base64_encode( serialize( $WP_Import->url_remap ) );
					$answer['featured_images']      = base64_encode( serialize( $WP_Import->featured_images ) );
					
					die( json_encode( $answer ) );
				break;
				
				
				
				case( 'install_demo_images' ):
					$WP_Import->missing_menu_items   = unserialize( base64_decode( $_POST['missing_menu_items'] ) );
					$WP_Import->processed_terms      = unserialize( base64_decode( $_POST['processed_terms'] ) );
					$WP_Import->processed_posts      = unserialize( base64_decode( $_POST['processed_posts'] ) );
					$WP_Import->processed_menu_items = unserialize( base64_decode( $_POST['processed_menu_items'] ) );
					$WP_Import->menu_item_orphans    = unserialize( base64_decode( $_POST['menu_item_orphans'] ) );
					$WP_Import->url_remap            = unserialize( base64_decode( $_POST['url_remap'] ) );
					$WP_Import->featured_images      = unserialize( base64_decode( $_POST['featured_images'] ) );
					
					ob_start();
					$WP_Import->backfill_parents();
					$WP_Import->backfill_attachment_urls();
					$WP_Import->remap_featured_images();
					$WP_Import->import_end();
					ob_end_clean();
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_slider';
					$answer['message']        = __('All Images were inserted successfully. Inserting demo sliders...', 'optico-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				
				
				case( 'install_demo_slider' ):
					
					$json_message		= __('RevSlider plugin not found. Setting the widgets and options...', 'optico-demosetup');
					
					if ( class_exists( 'RevSlider' ) ){
						$json_message	= __('All demo sliders inserted successfully. Setting the widgets and options...', 'optico-demosetup');
						
						// List of slider backup ZIP that we will import
						$slider_array	= array(
							THEMESTEK_OPTICO_DIR . 'demo-content-setup/sliders/sliderdemo.zip',
							THEMESTEK_OPTICO_DIR . 'demo-content-setup/sliders/sliderdemo1.zip',
							THEMESTEK_OPTICO_DIR . 'demo-content-setup/sliders/sliderdemo2.zip',
						);
						
						$slider			= new RevSlider();
						foreach($slider_array as $filepath){
							if( file_exists($filepath) ){
								$result = $slider->importSliderFromPost(true,true,$filepath);  
							}
						}

					}
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_settings';
					$answer['message']        = $json_message;
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
					
				break;
				
				
				
				
				
				case( 'install_demo_settings' ):
					
					
					/**** Breacrumb NavXT related changes ****/
					$breadcrumb_navxt_settings						= array();
					$breadcrumb_navxt_settings['hseparator']		= '<span class="ts-bread-sep"> &nbsp; &rarr; &nbsp;</span>';  // General > Breadcrumb Separator
					$breadcrumb_navxt_settings['Hhome_template']	= '<span typeof="v:Breadcrumb"><a rel="v:url" property="v:title" title="Go to %title%." href="%link%" class="%type%"><i class="fa fa-home"></i><span class="hide">%htitle%</span></a></span> ';  // General > Home Template
					$breadcrumb_navxt_settings['Hhome_template_no_anchor']	= '<span property="itemListElement" typeof="ListItem"><span property="name">%htitle%</span><meta property="position" content="%position%"></span>';  // General > Home Template
					
					// Getting existing settings
					$bcn_options    = get_option('bcn_options');
					if( !empty($bcn_options) && is_array($bcn_options) ){
						// options already exists... so merging changes with existing options
						$breadcrumb_navxt_settings = array_merge($bcn_options, $breadcrumb_navxt_settings);
					}
					update_option( 'bcn_options', $breadcrumb_navxt_settings );
					
					/**** Finish Breadcrumb NavXT changes ****/
					
					
					
					/**** START CodeStart theme options import ****/
					
					$theme_options = array();
					
					$theme_options['classic']	= 'eNrtXety2zqS_r9V-w5YTW3VpMq0eZNkaRzXuhzvOWfrJM7Gzp4fW1MsiIQkHlMki1ww7Wjn-F3m77zGPNl248KbRFme2Fwn9m6sOBHBBtD40Gh0Ny6hU9cZTf_Cp5PpgN_EaZglWTH4E5-Op4M_jOfh0LfxaTQdJHSdlQIf_OngLo4YfnWOp4N5mSQBJgQsYSuWCj74E52607_EU1tlXTIaMSg1njoqYZ5lAhPu-RQKSLJFJta5LHA4HcQrupDfzSv2RWgeLnMRhxk-TNS7YJ6lAqubYBuwZLqKk7Uu6ayIV5La8aaDGQ1vytyqCdxjSUGTA_IjS24ZFE0PCKcptzgr4rlG4ZYCTSr0U8EWZUIlQg7ggLxZooA886xYYao9HWj-kDWLx_8j2-JOB-5I5nKA8zhl1pLFi6Uw78amxIQJgMbiOQ3jdCFTpwNbN6jVO66NH90hCgcJwVwiyxYJk-COFUrxaoEYeYgRVBZHbUbFslxczayySCToXDDVUoh8enSUSbQPxRJ6lQt2cxhmq6MMWA-TOLyxBCQe3eVWCFVDrx8pOp3rSPZcIj_C6g9z1RAtK89e071GUrU84EB1s94bXDCd3GFWpt6r7lPizMU6YbovwoRyHoeyt2xDEMxEqkcCJA-byYGRaSzu7OPHy58-XFy_v_hwLZPalCArN1oK_tDhoCpFs-zWVcMwLIM847GIs1QLT2HkzYEmx-k84wKGRJCwuaj5GQHhSRTfEtmkt4MVi2JqIc3gtJkOwKeDU3ISmwTBLdUfFr6yVjROIMdRDL-Qzfy9UbJi6vRkOTq9wDyk5OTkCJ5Olt4pMvlvWjZAXCLwhQd1yqJMg-uGyKLqloydp2kJXCKaL1EYaVwiHtmkc5rIFqXZXd0qx_X84Wh8PHmgPbLSqj0T6LT_BtZAJoiIRcLetgSHSHF8O1wwFY3aZfD3vxK-pDmkFFmZRiyCFNQRwZ1UO28Ha8YHBIXr7VwwRHz6r67322-_Df4s2XBbckQLRoOWthrZ28Rttggq_QSjXCeixc2iYErVjjdJSy6yVZ0DZqFBsZjRP9oH8nPoOW9MVjWCgz0r8_zeHJ06UYvO5Y-SGNCdSTajSYBzxUIChwN4jAO4OTHp8TbWSS11gs1gOaOirUuaY1GnoqagArp6iZNm4wXyr6cNndJV_Ybpe4VbnKaoLV4P03L2xq6RM5NUbo4xXCfMC-BRd1izepgz5jNaWL26TRO0BKRr26CKVUQvBTKJ1S0rtuFmrLD7BuOoFer2QerdMhbMDN4GyRaJj1wiD36MxEvaJU2jBERI6kJAQlqEaDzEs4IWa50Tp914vjZTiH4pTTB6x3i2YmYgzymZU4sWRXZnRdldakA3WTol6UesHXSbhcO1Mod0Dr5QvEEDoYfVE1H_WL9kRRL90rBIq2o4KPKVyYj90EkZ1bSoNSGZmzJuQ0hcIvJva1bOZtqicr0tkAVhknH21cD5beDKfAdsqHw7sGkmXiZuleQqvLZKrrNBElRt8pWOl3SmKPA5FkwOg3IFhlLln1ww4l4gP9WAXDClXCLAnEbNMYPp7CbP4tT4Mo5rq_ls0kdo1XqoQY-GGF9md4HI8hm6BDPp3mBLVcpOHYRsNcgenJk07Y6B73eIthRpyx_ThZq6bVwwuvDipEwqYyhTZjcN0aRJwPbps5OSLKSo-aw8TpWZNB7aDjkHYU4ECN15yW4pXCefogPyQ5nM86wQB-T91QHxJsOh7Z0cYeFHZXLaaXHHrPNcJ338EWBoCcSJtr_azMaWiGGcScbeAzsWuaKCHB_aNnx18N-ag6ZNB4XCF3DkWG6lYJANTtEK41kIjqOF9hP_c23A1WzvEDN_C02PhHmV2VTbX5Dm6NcNT2HRPxs0SLo2l9e2uaTB5WFcIuM5jOn4lgU7ck90btc5UH_sw8nojXGtdcZGUe2h3xjRUsehN7-iX9qW5nBo-GxZdGasNUxQla1y9mTusW0waNuDvWhNtlHuHJpYeIf1Ng_-sNOTnNFcIlxcVtoCmZMpQZzmSn_hELxe54yAgo7I9ZKl5CPAyMlFKlhlLKtcXBh2CKQ_0LQ4mt6vrm5f93_y5E65JfHtCwI8b311DISzrHLPnSVMuVmqwkAofMpB6BuxOKpXbEGRykIrrZBzphZBdyN7z2BGQhqnSNwftUL-QD0JDrVQ8YSxKw-Hg90ft4J-KPOcFSFVE-6WXDCW4_cHsJzRzlwwlrPNsPUc_OwMYLnVyG9C11MKjhtDFsCEgDoHNXRL5-AkbNTcduLOePfVeDfDLiqyHE3ab9eNo6_tRu8f7kZ7l1-3qxs1cP09AwT1qMG-2U6-20yaNLI9lWsHZaaZVT93fDzs6JChXiYwqT-xu-d6tbypIAZYIRQEarvxbHSUMYz1tLBNPqEV_5UlyU1WpL-jjumPjTvjp1Ut-8iks1VaAuflRU9M8LmPZff1sey9Ppb918fy8PWxPHp9LI9fH8vHr4_lyQtm2e2ZSuyXy7MMVaCB0A1UQXazklwiY7MVzW6DamI_qSNnqrVmi8Nf88XT2GquXiggymL7WmutCoD4_oFnHzjDA_twNHmj4G1C1w7aNUOZToMK4wNg1gSv0zn07X4Lbmg_3oKLoslErVL0W3B-Az1ezr4hgF-3M8SZ7NgZ4j4_dhi6iMKiXFzNXiF2O4ISrv14b5bBj8K8Fztsd4XdbczuNLXcW2BWXDDqUd0I3HqNEHBFgDun6h7QrKeZKYlGt4FAwpAKWoRG8ZxTwRZZsSZnRbgEB5lPyUYOQRcmB9R4TRcdYvQvK2LQlELtY5nHLDJsfoRUTup0gpsJCl3XcSM7LcUyK0x1gOSZTOjWaOv9YmoHWO_Ec7xBRpPkeR15r3Lkd80OuPYUf1H47DFFYHvlFIHzA0wQzgS3Npg5wjY74YJQ0Ob6UZ36LZZkcQh31hbbm2Be6hrjqIVcXBUVdxCan-ZknZXkR3rLyFm6Jv9ZghkCfc_JVbhkUZkwQlNylssILvY2OZkVp-SEi1wiSxenv8RiSS7LgrzLQgFiffmJyM09nzm5TMkfbcd-47ie5Q9H1vh4Yp8c6XymZxp8wUzVDdjLNcqaYlYKkTU2iUH-9_Smy2B_xvaeMRV-m8cFF2Y8bSyZolwidatF2Cbpzn0Uk03i5x6nvdZvz8js2YzizPFTL-k3W9FvruFeJJTEqBfIzbXndoYmnDhpyVkup4XpT3tLhq-G9Ll29DgTZ-bMKnuizXg_ilwwyiwTGMjdH5SNDC97PugBzB7Bx69cMGs3aqeXUMlbvlYL4pWxgYCdm2Ty978R13aOyQkly4LN3z7CXCcbnF6mjJzjM7mG55MjenpIzkDJyaI5KRhYcLcsOjTO1IKlrKBJZTQCPF2rcYwmRJ7HWnlvtRhxuZMusxXYiT9Aibffzl70H28v-q4_8plBBKTSQlbVLnhZqBKnfmPSlpzcWE0tiz2_NPaEmjUNhdVou6-2dNTTZUVUZUYWZ044sb1qx4Dzkj3N_o7b5WDqRfbHbZ938LO7bxAu93XC5e04beDbXyPnu-HyXilcXDukyxs-H1xc_uuEy92hRb1nlK7hK4XL3THpPKN0jV5cJ1xczvHTxnT2gUtvlPt2WHmvSs9_23DrV4jWP27-bQ21jlk49B4WLb3WsQOrfQzl3zu0uuvA4vHjRWvk4mc3Vo48W4q7V16gWMnNPjSPBU00So_U9Z77eNT22CWHlenQj0Ft9LLi95vI7QZhZ-xdHzOu9zeNXs1ixehBxTpLsoUKBSTxKq52fGuj6lgT4HLBKisaxwOng0-QRt5Don6WhGZ5onNI1VevZ9kXHcLSklwnlgVjJpKLKwKB2uke8CXF2qqQKtBeYRIRy5gTpDSRCixXVxWsmKDQDi6qc7DAB0vpLGFyFdnHJAy06D6yq3WNmPEqClwijH59p78Camq5QT-cVQ-4MkMXmvyaLrg5Yx7FvKrV0YyE2cqEcY4xhrLSh9fv71Wob6MlyAp2ciuq5vpbKIEJFYTVm4S30UCjWzTbalTNbJENsWMKMc-SOAvyXCL7lYVcIoiAOE646ZqPny7_4-L8mry7uD776ecrE6ut86FYVAeYG0tXGJurqeTploIl0Oyoqt9rUuiXDcGA7vh08fPZ9cU7orm42izYZGtIp-TGcg2im7Q9crq1XFxkXFyrkyrukc8NSnI9QQcP8Y4CszXe2SBqtAua_WPGpQYjH6haV8HAZDfHjvUax1EDv7ky079oAyyzVS7Wu87OyYXG9smbb7o2M2qvzaSZUIpNDWPa2eh7j_dB7AM-5FHLLt9B3wL6sA261H-7MHf3whxQvCqLBSvW30F_WNJLrq8z6UXd2wv1xiT3HfIO5OM25GGSlVEX88peXDDE_b0QB87exZxRrgyOZ0W9Xodf0Rx-ixtWvKIekE0PuKAPiPpwvxl1w9j7jv3XYz_aV-h_1i17CarGczY3nNA0stRpuvpuhxe456SnI7QH0TGlm75UZU8ft8i2elvG2TJY9dDj6mwcMq49K3X9Fu6koiGbZdmNuYAL9w3dxUKoK7lcXFXBXCJPSo7PnvIeQeCBXDCXhbGZnt2qFbz1hOG5d3WZUXc3y2QHsdmb0th9kM9BFDd9Accsqqr32-3_On_D5p9Um-wYXQXgIRe0JdxcXAt20_if9FI3NxJNB5dhWOZy5EyrvVI9-f5fz9aPHjJNZ2Dfzrj4kjNcXGwP2ffOeOLOcB_XGS4GUApGrm7iJOHfe-OJe8N7XFxvQCPOWSHieQxtZt-74yksK_9RXTCpLazv6D-pT7HXXDCA-i_efT4_u_7p8sPvh399gxOaW6vm7Sb_V3riXlvrCOWKrWZ4oYky8PQtPPWuZfTv9M0876tJAjPusPb8mqLH3muU0bX4MLdv-w-dVDsePulJNajxSQ-pPemFAvUdPd6B-mMfHttvqhOArCiyQmIWL55wHEzMOJB3y3Are_AWuBc2GJqnJFsY1fdQTQcfz364IB8ur8m_X37-8M440hU53gZarho5MKSaFcX6gMxKQaD1JAdJkccScCUtAZ0BQ4nMs4JEGcNbQwVhX2IuCKQUbJXh3lvyMcFgFSnhV93tQxbxLUvJjCXZHcgMmcdpRO6WVGyUDMVgNqwZrz4heF710MBf8d25oMg3Vw2lYN_xUh__wPACXmb6IRNLxTQMN3mf6Ul-2mhlqt-vqMBjFshSYfgGGV_xqkGiWBO6QLbu8KwFyhKJ4vmc4TZwcsPWd1kR8cOTo_zUKAIOPW6OLm1cXATZfK9Hfn2ualK_bKiy7mLYcCtVgLol7575GjfZ0b5vq07c5rxBgYuA8hjXBvt-TW06pKcBd1kmVzKLkHVLadbZINMqe-OomSGdzXK8b2qDXCdsowo44Pjh1cqub1xcaXXV8aRcItMRiSDVC2atYMRWys51x8opfKjYZkBjv1LdPUrFgCFOA3sX6u2HXDDmA9WQPlCsUkH6KHGJeIuiDFE71nYOTsXXuFwwD_MHI_DvZzydR84bxEYjtktYilWiRNxt35JcXMqrm0EBw5Ax897g9J__qUOz7bW8GA-v2tIX4rUzcZbLZdfT6uXSMe_0TrLBKajRi0_k_PLD1fWnz-dovIFKcSSxXxVU7TwbgKJZMaVf9OyjtiPc0TUBWWegXFyuBHwXZcqif4GifCzK1F9fu-x34XnorPvTWhCtun9vW-KRBxrlznn5U9180IYu5BxMt4h1Lu3N5wFe8d8KQV9V8Uq9jt-kkTrK7LMZV8R1TFDR8qQ0WPENCjQSa5-grpF01h2cNnWrarQQOtkqi0hnMjyoW_kkqdXU69K4wfmjjcDYrGrzVriyB4LWGrjTXCI29eMlWzXJSJPI2aodG9BnGH_AN9zMdF3iNgpuO1erWSpThYJr2LCqiRIvZotTaevVh1xczWVeWwTGr97-uvmyyopKTG5w7tyB33g7y6I1ujRNsxkFoUPC0lYZjrwyME6DHSxONhoQ6DFWD9R4hRN9p2EwtaorrrX_MpNh-om-07aZJs-91UfzUS_JA2PmvVNdbGn-Pw2dji7yOs-CBO-yRY-XyRvgTbGjbVu76sUDXUjdQ9os4J0h3Rr3VTYPTzwxaXIFXFxeTqZrhabLo-4RGLKB2Q-LitBkvv9f9_zleA';
					$theme_options['overlay']	= 'eNrtXety2zqS_r9V-w4YTW3VpMq0eZNkaRzXuhzPOWfrJM7Gzp4fW1MsiIQkHlMki1ww7Wjn-F3m777GPNl248KbRNk-cRJrXCdWnIhgA2h86G40GpfQqescT__Gp5PpgN_EaZglWTH4M5-Op4M_jufh0LfxaTQdJHSdlQIf_OngLo4YfoW8g3mZJAEmBCxhK5YKPvgznbrTv8VTW2VdMhoxKDWeOiphnmUCE-75FApIskUm1rkscDgdxCu6kN_NK_ZJaB4ucxGHGT5M1LtgnqUCq5tgG7BkuoqTtS7prIhXktrxpoMZDW_K3KoJ3GNJQZMD8iNLbhkUTQ8Ipym3OCviuUbhlgJNKvRTwRZlQiVCDuCAvFmigDzzrFhhqj0daP6QNYvH_yPb4k4H7kjmcoDzOGXWksWLpTDvxqbEhAmAxuI5DeN0IVOnA1s3qNU7ro0f3SEKBwnBXCLLFgmT4I4VSvFqgRh5iBFUFkdtRsWyXFzNrLJIJOiQsBRcIp8eHWUS7UOxhF7lgt0chtnqKAPWwyQObywBiUd3uRVC1dDrR4pO5zqSvciPsHrrbhkLdpir5miJ-Ur13WtUFQoBB9qb9aPB0MkdlmXqvepKJdpcXKwTpQ_YSQnlPA6t7JYVoDQy2TaUwUykWj0UdZ0cGEHHcs_ev7_86d3124t316bcBiUI0I0WjT92WKlK0by7ddWgm2WQZzwWcZZqiSqMEDrQ9jidZ1xcgJ4ECZuLmp8REJ5E8S2RTXs9WLEophbSDE6b6dAP6eCUnMQmQXBLdY-Fr6wVjRPIcRTDL2Qzf2-UrJg6PVmOTi8wDyk5OTmCp5Old4pM_rsWFRAQfOFBnbIo0-C6IbKouiVj53lagojmS5RNmohcJzbpnCayRWl2V7fKcT1_OBofTx5oj6y0as8EOu2_gTWQCVwiYpGw1y3BIVIuXw_AbqPJGfzj74QvaQ4pRVamEYsgBQ1HcFwnbdHrwZrxAUHhej1cMFmf_pvr_fbbb4O_SjbclhzRgtGgZcJG9jZxmy2CymiBGkW0uFkUTNnf8SZpyUW2qnM4YM6KxYz-yT6Qn0PPeWWyKlUOHlmZ5_fm6NSJpnUuf5TEgEFNshlNAhxAFhI4VOAxKnBztNL6NtZJLbuCzWA5o6JtVJq6qFPRUlABXb3EkbTxAvnXY4lO6Y4Hhul7hVucpmgt9odpOaRj18jhSho3x_gY5gXwqDusWT2M7vMZLaxe26YJWgLSdXjQxCqilwKZxOqWFdtwM67ZfYNxtAp1-yBVjoNGeRskWyQ-ijz4MRIvaZc0jRIQIWkLAYkRXCKBHkU8K2ix1jlxFI7nazOE6JfSL6N3jGcrZhR5TsmcWrQosjsryu5SA7rJ0ilJP2LtYNssVNfKR9I5-ELxBg2EHlZPRP1j_ZIVSfRLw02tquFgyFcmI_ZDXCdlVNOi1YRkbsq4DSGJyL-tWTmbaTfL9bZAFoRJxtlnA-e3gSvzHbCh8e3Appl4mbhVkqvw2iq5zgZJULXJVzZe0pmiYFwismBSDcoVOErVpAUQ9wL5qRQCjIpcMB8bLccMhrObPItTM8FxXFxbjWeTPkKrtkMNenTE-DK7C0SWz3CeMJNzHmypSmnZoK6ONkgeHJU07Q6l9ztEW4q05Y_pPk3ddv5cXHhxUiaVI5QpD5yG6M4k4Pf0-UhJFlK0elYep8pFGg9th5yDIFwnAgTuvGS3lJMP0QH5oUzmeVaIA_L26oB4k-HQ9k6OsPCjMjnttLjj0vmTPv4IMLQE4kT7Xm1mY0vEoGOSsbfAjkWuqCDHh7YNXx38t-ag6c9BofAFZnYst1Jwxgan6IHxLISZpIW-E_9r7bzVbO8QMX8LTY90eZXLVPtekObo141ZQkPKoAPr0hp-3DaHy2s7XFzS2_IwkfEcFDq-ZcGO3BOd23UO1B_7cDJ6ZSbbOmOjqLbeN9RZGjic36_op7abORwaPlvunFG0hv-pslVTPpl7bBsM2s7gLsdcME3AJvVO_cQKOuy3-fCHne7kjBbhsjIXyKBMCeI0VwYM9fB6nTMCFjpcItdLlpL3XDAlXCcXqWCVt6xyYTBcIpATgqbL0ZwH6-r-aYMCOjLCWVbNz50ljLlZqoJDKIBqhtCntqjaK7agSCXn-oUcNLUYuhvZezQaCWmcXCJxfywL-QMbJTjUQsUzRrQ8VAm7P5oF_VDmOStCqkbcLWEtx-8PazmjnWEtZ9eMYEdYy620vwldny6OaoQDGBXQ7qCZ7rGPaOy2k3c03le1GMWLiixHr_bbdeToczvS-90daf_ejtTAPaFvtpPv9pYmjWzPNbuDMtPMqp870zzs6JChZSYwtj_zjM_1anlTcQxwRigI1Hb_2Vgp4xvrgWGbfEIr_itLkpusSL-ilemPmTvjr29cXJyt0hI4Ly-AYgLRfSy7-8eyt38s-_vH8nD_WB7tH8vj_WP5eP9Ynrxglt2eocR-uTzLiAU6CA_Gy1wnTcLdXtXEftb5nKnWmi0Of80Xz-OwuXrBgCi37XNdtioW4vsHnn3gDA_sw9HklcK4Cd2OXDCe0yDDOAE4N8F-ThJ9u9-PG9pP9-OiaDJRyxX9fpzfQI-Xs28I4OftG3EmO_aNuF8eOwxhRGFRrmZ7iN2O4IRrP31Oy-BHYd6LHba7wu42ZneaWm4yMEsBtVY3orijRjy4XCLAfVV1D2jW08yURKPbQCBhSAUtQmN5zqlgi6xYk7NcIlxcwjSZT8lGDkEXJgfUeE0XHWKcZVbEYCqF2tgyj1lk2HwPqZzU6QR3FRS6ruNGdlqKZVaY6lwwyTOZ0K3R1rvJ1P6w1vADtZm1_GrTWU1Gk-TLTue9ajq_a3jARaj4k8LnEWMEtleOEThAwAjhTHCPgxkkbLNPLggFbS4k1anfYm0WVbizyNjeDfNSFxtHLeSq6LiD0Pw0XCfrrCQ_0ltGztI1-c8S_BDoe06uwiWLyoQRmpKzXFxGcrG3ycmsOCVcJ1xcFFm6OP0lFktyWRbkTRYKEOvLD0Tu8vnIyWVK_mQ79ivH9Sx_OLLGxxP75EjnMz3T4AtGqm7gXi5W1hSzUoissVsM8r-lN10G-zO2N4-pINw8Lrgw-rSxdoqG1K1WY5ukDzmIXeIvrae9PnCPZvbsSnHm-KnX9putaPtrzSVo3JSEkhj1Arm5CN3O0IQTBy05yuW0MP1pb8nw2ZB-qa09zsSZObPKn2gz3o9cIoAyywSGcx8PykaGlz0e9FwwZo_g41eAtRvVD5hTK3mWr9XqeOVsIGDnJpn843-JazvH5ISSZcHmr58wKRucXqaMnOMzuYbnkyN6ekjOwMjJojkpGHhwtyw6NLOpBUtZQZPKaQR4ul7jGF2IPI-18d7qMeKyXCddZivwE3-AEm-_nb_oP91f9F1_5DODCEilhayqPfKyUCVO_c6kLTm5sZpWFnt-afwJNWoaCqvRdl_t76iHy4qoyowszpxwYnvV9gHnJc80-ztu1wRTL7Y_bXO9g5_dfYNwufsJl7fjLIJvf46c74bL21O4dkiXN_xycPn7CZe7w4p6X1C6hnsKl7tj0PmC0jXaT7ic4-eN6TwGLr1p7tth5e2Vnf-24dbPEK3f7_5tDbWOWTj0HhYtvdixA6vHOMpfO7S66zjj8dNFa-TiZzdWjjx5intYXqBYyS0_NI8FTTRKT7T1nvt01DwHPw-ipkM_BrXRy4rfb1witxuEnbF3fQi53uU02pvFitGDhnWWZAsVCkjiVVxcbf_WTtWxJsDlglVWNM4JTgcfII28hUT9LAnN8sS4OrVq-MbXs-yTDmFpyRPLglWTWUNhypjIXexWFWrBwBmuGgRqa3zAlxQ5qsKuUN4VJhGxjDlBShPNwJI1O8GKCQpt5aI6NAu8spTOEiaXmn1MwmCM7ke7WvuIGa9cIiXC2OA3-isgq5Yk9MNZ9YCrN3Shya_pgptT6lHMq1odzUiYrUyo5xjjLCt9_P3-XoUDN1qCrKAgtFwib66_hRKYUIFavaF4Gw00ukWzrUbVzCaZM6477yF4Xa07PWBtA3cTLe-hPtqB5PYO0XHZViu2Q2t3qLqwdt93Ie3WsglcJ548wrMr8yyJsyAvsl9ZKIIIiOOEG0l__-HyPy7Or8mbi-uzn36-MuHxOh9qUXWKvLFaiOHQmkqeLCpYAk2NmizWFPplQ8-gwz5cXPx8dn3xhmgurjYLNtkaBkFyY7lGQDdpt5uG7eVcIuPaglehpnxuUJJLODpei5dGmFMJzgZRo13Q7B8zLgcN8o6qpSzszm6OHUtkjqNsbXMxrH-dDFhmq1xcrHedW5Rru-2TT990OWzUXg5LM62hSnFpZ4f1PV7Q8RjwIY9a6foO-hbQh23QpfXahbn7KMwBxauyWLBi_R30hyW95Pp-mV7UvUeh3vAZvkPegXzchjxMsjLqYl55CIC4_yjEgbM3MWeUK9_gi6Jeb31Y0Rx-ixtW7FEPyKYHXFzQB0R9-LgRdcMv-47952M_eqzQ_6xb9hJMjeds7vGhaWSpg4z1vRovcJtPT0foCVnHlW5OTSt_-rhFtnXyauauBqseelxcEI9DxvVEVd2HhpvXaMhmWXZjbkTDrVp3sRDqjjRXVbDIk5Ljs6cm1yDwQIAr8dhMz27VGqeLhOGdA-pcIqnuBqLJDmKzHaix4SOfgyhuzgUcM_VX73tCA1X-hs8_qfY1MroK2FwnUdCWcHMt2E3nf9JL3dy7NR1cXIZhmUvNmVbb03ry_VOP1k9WmeZk4LGdcfEpZ7i_IWTfO-OZO8N9Wme4GEUpGLm6iZOEf--NZ-4N72m9AY04Z4WI5zG0mX3vjufwrPxcJ3XBpPawvqP_rHOKRylcMNR_8ebj-dn1T5fvvh7-9e1Z6G6tmpfL_H_piXvtrSOUK7aa4V0yysHTtyDVG8VxfqdvRnpbDRKYcYe359cU_UtBhqLr8WFu3_YfOh14PHzW04FQ47MeDHzWmxzqK5K8A_XHPjy2X1VHL1lRZIXELF48ox5MjB7Ia324lT14A98LU4bm8dQWRvU9YNPB-7MfLsi7y2vyl8uP796YiXRFjjexlqtGDgypZkWxPiCzUhBoPclBUuRJEFxcmEzAZoAqkXlWkChjeGOrIOxTzAWBlIKtMtzuTN5cJxisXCIl_KprlchcIr5lKZmxJLsDmSHzOI3I3ZKKjZKhGMyGNeOdMwQPCh8a-Cu-O3dD-eaWpxT8O17qEzcYXsCLZN9lYqmYBnWTd8me5KeNVqb6_YoKPNmCLBWGb5DxFa8aJIo1oQtk6w6Pt6AskSiezxnuvFwnN2x9lxURPzw5yk-NIeDQ4-a02MYlnM33Zo24Oso2qV82TFl3MWy4lSpA25J3j9mNm-zouW-rTtxZvkGBC4Dy5NwG-35NbTqk2VwwrE7N_VGUebWo6ptZrbrxeVKR6eBAkOq1q1ZcXGArZefWZzU_e6jYZmzhcaW6jygVY3dokR9dqPc4BDAfaGn6QLHKGuiT1CXiLYoyRENVuxw4Kl7j1gIw5YzAvx_xbFwiOW8QG-PULmEpVomSNrd9WXQpb7AGWwjSa4agwem__kuHZttreUcgXjim7wZsZ-Islyugp9XLpWPe6X10g1OwaBcfyPnlu6vrDx_P0Y8C7XYksV8VVO27G4DOr5hSdT0QqI0Wd3RNYFBloOdXAr6LMmXRH6AoH4sy9de3T_tdeB466v-8g3mr7q89rD_xOKc8NyB_qtsf2tCFnIMXFbHO3cX5PMD__qAVDb6qQod6Sb1JIz08s8toXFwR1-E5RcuT0mDFNyjQX6vd87pG0lkCcNrUrapxsO5kq5wTncnwoO4mlKRW08RKPwNNeRuBsVlg5q3IYQ8EreVop0Vs6seLxmqSkSaRA0d7mq5PcP6Ab7gZdLrEbRTcdq5Ws1SmCgXXsGFVYxZeTxen0u2qj_iaC822CIxfvf1182WVFY2Y3N7d2QzTeDvLojXOLpoeLApCh4SlrTIceXFinAY7WJxsNCDQOlYrarzCMbfTsLxg6qZvPZWYyYj5RF_t20yTG3fqiwnQLsnjcua9U13xaf6vEZ1vtG1XWh2o17nrLtBjPu_obEuxq2weHuhi0r0JuLzFQ9cKbZNcJ_kjcBoDs90XLZ3JfP9_Mgg7Kw';
					$theme_options['infostack']	= 'eNrtXety27iS_r9V-w5YnT9cJ1WmzZskS8fHtS7HOzNbkzgbOzs_trZYEAVJHFMEi1ww7WhP-YHOa5xcJ9tuXFx4kyjbE1wnsXdjxYkINoDGh-5Go3EJnfreaPo3MZ1MB-ImyWKe8mLwFzEdTwd_Gi_iYeji02g6SOmGlxIfwungLpkz_OodTweLMk0jTIhYytYsk2LwFzr1p39Lpq7OumJ0zqDUZOrphAXnEhPuxRQKSPmSy02uChxOB8maLtV3-4p9loaHy1xcJjHHh4l-Fy14JrG6CbYBS6brJN2Yks6KZK2ovWA6mNH4psydmsA_VhQ0PSA_s_SWQdH0gAiaCUewXCJZGBRuKdBk0jwVbFmmVCHkAQ7ImyMLyLPgxRpT3enA8IesOVwi-R_VFn868EcqlwecXCcZc1YsWa6kfTe2JaZMAjSOyGmcZEuVOh24pkGt3vFd_JgO0TgoCJacL1OmwB1rlJL1EjEKECOoLJm3GZWrcj1zylwiVaADVCsp8-nREVdoH8oV9KqQ7OYw5usjDqzHaRLfOBISj-5yXCeGqqHXjzSdyXWkelEcYfWHuW6IkZWvXtO9QVK3PBJAdbN5NFwwJrnDrEq9192nxVnITcpMAUm24EKCgKn-ci1JNJOZ0QVIHjaTIyvVWODZhw-Xv7y_fnfx_loltSlBWm6MHPypw0NVimHar6sGRSyjnItEJjwz4lNYifOaPEcpW8ianxEQnsyTWxKnVIi_DtZsnlAHaQanzXSAPhuckpPEJkjh6B5x8JWzpkkKOY4S-IVs9u-tkjVTp1wnq9HpBeYhpSBcJ0fwdLIKTpHJfzXSATKBLwKoUxVlG1xcN0QVVbdk7D1PSxDRfIXiSFP5xCad01S1KON3das8PwiHo_Hx5IH2qEq3-thv9TEtGI1atmTk7hKF2TKqrAfI9pwWN8uCaUM43iYtheTrOgeMEYNiOaN_dg_U5zDw3tisWr-iR1YWhL05OnWijVuoH92bYNlSPqNphJZ8WfAym6NyjVG5msOGwWlsklrKjs1gOaOyrelNPTGpqMVUQjescEhrvED-jVE3KV3DbJm-17glWYaa_HqYVmMrdo0aN5Th8exgb19cMI-mw5rVg0VfzGjh9NodQ9ASkK7ngeZPE70UyBRWt6zYhZv1ke4bjKPG1u2D1LtVXCKZVd4GyQ6Jn88D-LESr2hXNJunIELKTgESyl_DoT2ZFbTYmJw4KCaLjTXv5qVykOgdE3zNrFwiLyhZUIcWBb9z5vwus6DbLJ2SzCPWTmTioLpWzorJIZaaN2gg9LB-XCL6H-c3XqTz3xr-YlWNXDAju7YZsR86KaOaFj0mSBa2jNsYkoj625mVs5nxd_xgB2RRnHLBvhi4sA1cXJnvgQ2Nbwc2w8TLxK2SXFyN107J9bZIoqpNobbxis4WBTOCJVNqUK7BialmD4B4EKlPpRBgVCQ4u2g5ZjCc3eQ8yexMw_NdPZ5N-gid2g416NFJEit-F0mez9Bhn6nJB7ZUp7RsUFdHGyQPjkqGtq30TUTCDs2OEl31Y3vPULf9Mh9enJRp5aNw7Q_TGD2NFFxckj73JeUxRaPn5EmmvZfx0PXIOchxKkHezkt2SwX5OD8gP5XpXCLnhTwg764OSDAZDt3g5AgLPyrT006DO95WOOnjj1wwQysgTo1b1GY2cWQCKqYYewfsOOSKSnJ86Lrw1cN_aw6arhYUCl9ghsVyXCcDP2lw-l-QJHgMMzoHfWbx37VfVbO9R8LCHTQ9whVUHlPtekGaZ143HPg9QtYg6bpbQdvdUr5WgIlM5KDOyS2L9uSemNy-d6D_uIeT0Rs75zUZG0W1tb4husq84TR7TT-3nczh0PLZcuasmjW8T52tmoWp3GPXYtB2BXvRmuyi3KuZWHiH9TYP4bDTk4LRXCJeVYYCmVMpUZLl2nShCl5vckbANs_J9Ypl5APAKMhFJlnlXCfrXFwYD4hkXCLTpq_Smpaa6h47L588-2zZUfj2zc6_bn11cEIwXs2avRWMtjzT8RkUPj036NNY1Oo1W1KkctBBK9RwaUTQ38reo8xISJMMifvDScgfmFwnKaAWKp8xqBSgOrj9ASXohzLPWRFTwXpcIkte2B9Z8kZ7I0vevrnAnsiSX2l-E7pWKYGHH6s3liyCAQFtDlrols3BOYA1c7uJO_oeak6t2s0LnqM3-_26cfSl3Rj84W50_2g3GuD6ewYIaq3BvtlNvt9LmjSyPdesDsrMuFM_d6Z32NExQ7tMYFB_5pmeH9TypuMX4IVQEKjdfrO1UdZcJzbDwi75hFb8XCdP0xteZN_QxvQHrb3xtzct3k5pibyXFzixUeE-lv3Xx3Lw-lgOXx_Lw9fH8uj1sTx-fSwfvz6WXCcvmGW_ZyhxXy7PKlSBDkI3RgXZ7VwiigrLVjT7HaqJ-6wTOVutM1se_p4vn8dX880aAdEe25d6a1VcMCQMDwL3wBseuIejyRsNbxO6_pid16DC-FwwuDXR65wchm6_Bzd0n-7BzeeTiV6g6PfgwgZ6opx9R1wwv2zLhjfZs2XD__rYYehiHhflevYKsdsTlPDdp89mGfxozHuxw3ZX2N0m7M5QqyV_G_yvtboRuA0aIeCKXDC3NNU9YFjPuC2Jzm8jiYQxlbSIreE5p5ItebEhZ0W8ggmymJKtHJIubQ6o8ZouO8Q4v6yIwVJKFfNOFgmbWzY_QKogdToB-88KU9dxIzst5YoXtjpA8kwldGt0zUYuvTWrd-A53lwio2n6dVwn8kE1kd83OuCyU_JZ4_OIIQLbq4YIHB9ggPAmuKvBjhGu3aIWxZI2l47q1O-xGosq3FlWbO9NeanLi6MWclVU3ENoflmQDS_Jz_SWkbNsQ_6jBDcE-l6Qq3jF5mXKCM3IWa5cIrjY2-RkVpySEyELni1Pf0vkilxclgV5y2MJYn35kag9N58EuczIn13PfeP5gRMOR874eOKeHJl8tmcafMFI1Q3Yq-XJmmJWSskbe7cg_zt602WwP2N7K5cOvy2SQkirT1urpWhI_Wr9tUm6dwvFZJv4a-tpr_fbo5k9-1C8BX7q1fxmK_rdNdyGhJI47wVye9m5naEJXCcOWmqUy2lh-9PdkeGLIf1am3m8iTfzZpU_0Wa8H0VcMGXGJQZyHw_KVoaXPR70XDDmjuATVoC1G7V3llDJW77RC-KVs4GAndtk8o-_E9_1jskJJauCLf76hDnZ4PQyY-Qcn8k1PJ8c0dNDcgZGThUtSMHAg7tl80M7mVqyjBU0rZxGgKfrNY7RhcjzxBjvnR4jLnfSFV-Dn_gTlHj7_fzF8On-YuiHo5BZREAqHWRVb09XhWpx6ncmXcXJjdO0stjzK-tP6FHTUjiNtod6S0c9XFxWRFVmZHHmxRM3qHYMeC95ptnfcfsmmGaR_Wn72j387O8bhMt_nXAFe44BhO6XyPl-uIJXCtce6QqGXw-u8HXC5e-xosFXlK7hK4XL3zPofEXpGr1OuLzj543pPAYus1Hu-2EVvCo7_33DrV8gWn_c_dsZah2zeBg8LFpmrWMPVo9xlL91aHXfScLjp4vWyMfPfqw8degTd6-8QLFSm31onkiaGpSeaOsD_-mo1fvb9qJmQj8WtdHLit9vI7cfhL2xd3P-t97fNHo1ixWjBw3rLOVLHQpIk3VS7fg2TtWxIcDlgjUv6lN7UNlHSCPvINE8K0K7PAF86yB-tRyAr2f8swlhGcmTq4IxG8nFFYFI73SPxIpibVVIFWivMInIVVwiCFLaSAWWa6qK1kxSaIeQ1fFU4INldJYytYocYhIGWkwfudW6RsJEFQWR1r6-NV8BNb3cYB7OqgdcXJmhS0N-TZfCHv6eXCeiqtUzjMR8bcM4xxhDWZtT5ff3OtS31RJkBTu5FVXzwx2UwIQOwppNwrtooNEtml016ma2yIbYMYVcXPA04VFe8N9ZLKM5EFwnqbBd8-Hj5b9fnF-TtxfXZ7_8emVjtXU-FIvqZHFj6QpjczWVOthSsBSaPa_qD5oU5mVDMKA7Pl78enZ98ZYYLq62C7bZGtKpuHF8i-g2bY-c7iwXGTfmpIp75AuLklpPMMFDvDzAbo33toga7YJm_8yFsmDkPdXrKhiY7ObYs17jeVrxmysz_Ys2wDJb53Kz79icWmhsn7z5rmszo_baTMalNmxajWlno-89XtTwGPAhj152-QH6DtCHbdCV_duHuf8ozAHFq7JYsmLzA_SHJb0U5p6RXtSDR6HeGOR-QN6BfNyGPE55Oe9iXvkLgHj4KMSBs7eJYFRoh-Orol6vw69pDr_FDSteUQ-opkdC0gdEffi4EXXL2fuB_ZdjP3qs0P9qWvYSTE3gbW84odnc0afp6msdXuCek56OMDOIjivdnEtV_vRxi2znbMtOtixWPfS4OpvETJiZlb4XC3dS0ZjNOL-xN2PhvqG7REp9V5avK1jmaSnwOdCzRxB4IMBlYWxm4LZqhdl6yvDIu75jqLubZbKH2O5Naew-yBcgittzAc8uqur3u_3_On_D559Um-wYXUcwQy5oS7iFEeym8z_ppW5uJJoOLuO4zJXmTKu9Uj35_l-P1k9WmeZk4LGdcfE5Z7jYHrMfnfHMneE_rTN8DKAUjFxc3SRpKn70xjP3RvC03oBGnLNCJosE2sx-dMdzeFbhk7pgUntYP9B_1jnFoxRcMOq_ePvp_Oz6l8v33w7_-vImdLfWzdtN_q_0xL3x1hHKNVvP8EIT7eCZW3jqXcs4vzM387yrBgnMuMfbC2uKHn-vUUbX48PcoRs-dFLtePisXCfVoMZnPaT2rBcK1Hf0BAf6j3t47L6pTlwwsqLghcIsWT6jHkysHqi7ZYTDH7xcMO6FKUPzlGQLo_oequngw9lPF-T95TX5t8tP79_aiXRFjpd0lutGDgyp8qLYHJBZKQm0nuQgKepYAq6kpWAzQJXIghdkzhle5ikJ-5wISSClYGuOe2_JhxSDVaSEX323D1kmtywjM5byO5AZskiyOblbUblVMhSD2bBmvPqE4HnVQwt_xXfngqLQXjWUgX9cJ0pz_APDC3jH6HsuV5ppUDd1zehJftpoZWber6nEYxbIUmH5Bhlfi6pBstgQukS27vCsBcoSmVwniwXDbeDkhm3ueDEXh1wnR_mpNQQCetweXdq6A7L53mh-fa5qUr9smLLuYthwXCdVhLYl7575GjfZMXPfVp24zXmLAhcB1TGuLfbDmtp2SE8D7jhXK5lFzLqlNOtskBmTvXXUzJLOZjneN7XFE7ZRBxxQf0S1shvaqbS-gXhSkZmIRJSZBbNWMGJcJ2XnFmI9KXyo2GZA43Gl-o8oFQOGOAw8utDgcQhgPjAN2QPFahNkjhKXiLcsyhitY-3n4FB8jQvwMH4wAv9-wtN55LxBbC1iu4SVXFynWsT99uXFpbpRGQwwqIwd9wan__xPHZpdr9XFeHjVlrkQr51JsFxcLbueVi9Xnn1ndpINTsGMXnwk55fvr64_fjpH5w1MiqeIw6qgaufZXDAMzZpp-2JGH70d4Y5uCMg6A-NyJeG7LDM2_xcoKsSibP31bchhF56Hzro_rwfRqvtb-xJPPNCods6rn-rmgzZ0sRDgus1Z577efBHh3futEPRVFa806_hNGmWj7D6bcUVcXMcENa1IS4uV2KJAXCexnhPUNZLOuoPXpm5VjR5CXCdb5RGZTJYHfSufXCJ1mnZdOTc4frQRGNtVbdEKV_ZA0FoD91rEtn68ZKsmGRkSNVq1YwPmDONP-EbYka5L3EbBb-dqNUtnqlDwLRtONVDixWxJpny9-pCrvcxrh8CE1dvft19WWdGIqQ3OnavpG29nfL7BKU3TbUZB6JCwrFWGp64MTLJoD4uTrQZERsdqRU3WONB3GgZDq77d2sxfZipMPzHX2TbT1Lm3-mg-2iV1YMy-96qLLe1_dGHScYq8yXmU4jW2OOOF9ukdPK5xCra3dtWLB6aQuoeMWyA6Kt3S-ypbgFwnnphyuVwioS5cJzO1QtPVUfc5OLKR3Q-LhtBmvv9f3MPBdA';
					
					
					if ( !function_exists( 'ts_cs_decode_string' ) ) {
						function ts_cs_decode_string( $string ) {
							
							// decode the encrypted theme opitons
							$options = unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
							
							// changing image path with client website url so image will be fetched from client server directly
							$demo_domains = array(
								'http://optico.themestek.com/optico-data/',
								'http://optico.themestek.com/optico-overlay/',
								'http://optico.themestek.com/optico-infostack/',
								'http://optico.themestek.com/',
							);
							
							// getting current site URL
							$current_url = get_site_url() . '/';
							
							
							// Getting layout type
							$layout_type = 'classic';
							if( isset($_POST['layout_type']) && !empty($_POST['layout_type']) ){
								$layout_type = strtolower($_POST['layout_type']);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
							}
							
							foreach( $options as $key=>$val ){
								
								if( is_array($val) ){  // if stored value is array
									foreach( $val as $val_key=>$val_val ){
										if( substr($val_val,0,7) == 'http://' ){
											
											switch( $key ){
												/*  This is not required in this theme
												case 'logoimg':
													$logo_img_file = ( !empty($layout_type) && $layout_type=='overlay' ) ? 'logo-white.png' : 'logo.png' ;
													$val_val       = get_template_directory_uri() . '/images/'.$logo_img_file;
													$options[$key]['thumb-url'] = $val_val;  // update value
													$options[$key]['full-url']  = $val_val;  // update value
													break;
													
												case 'logoimg_sticky':
												
													if( !empty($layout_type) && $layout_type=='overlay' ){
														$val_val = get_template_directory_uri() . '/images/logo.png';
														$options[$key]['thumb-url'] = $val_val;  // update value
														$options[$key]['full-url']  = $val_val;  // update value
													}
													break;
												*/	
												case 'fbar_background':
													$val_val = get_template_directory_uri() . '/images/floatingbar-bg.jpg';
													$options[$key]['image'] = $val_val;  // update value
													break;
													
												case 'titlebar_background':
													
													$titlebar_bg = ( !empty($layout_type) && ($layout_type=='overlay' || $layout_type=='infostack') ) ? 'titlebar-bg-overlay.jpg' : 'titlebar-bg.jpg' ;
													$val_val = get_template_directory_uri() . '/images/' . $titlebar_bg;
													$options[$key]['image'] = $val_val;  // update value
													break;
													
												case 'full_footer_bg_all':
													$val_val = get_template_directory_uri() . '/images/footer-bg.jpg';
													$options[$key]['image'] = $val_val;  // update value
													break;
													
												case 'first_footer_bg_all':
													$val_val = get_template_directory_uri() . '/images/footer-all-bg.jpg';
													$options[$key]['image'] = $val_val;  // update value
													break;
													
												case 'login_background':
													$val_val = get_template_directory_uri() . '/images/login-bg.jpg';
													$options[$key]['image'] = $val_val;  // update value
													break;
													
												case 'uconstruction_background':
													$val_val = get_template_directory_uri() . '/images/uconstruction-bg.jpg';
													$options[$key]['image'] = $val_val;  // update value
													break;
											
											}
											
										}
									}
									
									
								} else {  // if stored value is string
									
									
									if( substr($val,0,7) == 'http://' ){
										$val = str_replace( $demo_domains, $current_url, $val );
										$options[$key] = $val;
									}
									
								}
								
								
							}  // foreach
						
							return $options;
						}
					}
					
					
					
					// Update theme options according to selected layout
					if( !empty($theme_options[$layout_type]) ){
						$new_options = ts_cs_decode_string( $theme_options[$layout_type] );
						
						// Image path URL change is pending
						// we need to replace image path with correct path 
						
						update_option('optico_theme_options', $new_options);
					}
					
					/**** END CodeStart theme options import ****/
					
					
					
					
					
					/**** START - Edit "Hello World" post and change *****/
					$hello_world_post = get_post(1);
					if( !empty($hello_world_post) ){
						$newDate = array(
							'ID'		=> '1',
							'post_date'	=> "2014-12-10 0:0:0" // [ Y-m-d H:i:s ]
						);
						
						wp_update_post($newDate);
					}
					/**** END - Edit "Hello World" post and change *****/
					
					
					
					
				
			        // Import custom configuration
					$content = file_get_contents( THEMESTEK_OPTICO_DIR .'demo-content-setup/one-click-demo/'.$filename );
					
					if ( false !== strpos( $content, '<wp:theme_custom>' ) ) {
						preg_match('|<wp:theme_custom>(.*?)</wp:theme_custom>|is', $content, $config);
						//var_dump($config);
						if ($config && is_array($config) && count($config) > 1){
							$config = unserialize(base64_decode($config[1]));
							//var_dump($config);
							if (is_array($config)){
								$configs = array(
										'page_for_posts',
										'show_on_front',
										'page_on_front',
										'posts_per_page',
										'sidebars_widgets',
									);
								foreach ($configs as $item){
									if (isset($config[$item])){
										if( $item=='page_for_posts' || $item=='page_on_front' ){
											$page = get_page_by_title( $config[$item] );
											if( isset($page->ID) ){
												$config[$item] = $page->ID;
											}
										}
										update_option($item, $config[$item]);
									}
								}
								if (isset($config['sidebars_widgets'])){
									$sidebars = $config['sidebars_widgets'];
									update_option('sidebars_widgets', $sidebars);
									// read config
									$sidebars_config = array();
									if (isset($config['sidebars_config'])){
										$sidebars_config = $config['sidebars_config'];
										if (is_array($sidebars_config)){
											foreach ($sidebars_config as $name => $widget){
												update_option('widget_'.$name, $widget);
											}
										}
									}
								}
								
								if ( isset($config['menu_list']) && is_array($config['menu_list']) && count($config['menu_list'])>0 ){
									foreach( $config['menu_list'] as $location=>$menu_name ){
										$locations = get_theme_mod('nav_menu_locations'); // Get all menu Locations of current theme
										
										// Get menu name by id
										$term = get_term_by('name', $menu_name, 'nav_menu');
										$menu_id = $term->term_id;
										
										$locations[$location] = $menu_id;  //$foo is term_id of menu
										set_theme_mod('nav_menu_locations', $locations); // Set menu locations
									}
								}
								
							}
						}
						
							// Change homepage slider according to selected header
						if( $layout_type == 'infostack' ){
							// Change Homepage
							$front_page_id = get_page_by_title( 'Homepage 2' );
							update_option( 'show_on_front', 'page' );
							update_option( 'page_on_front', $front_page_id->ID );

						} else if( $layout_type == 'overlay' ){
							// Change Homepage
							$front_page_id = get_page_by_title( 'Homepage 3' );
							update_option( 'show_on_front', 'page' );
							update_option( 'page_on_front', $front_page_id->ID );
							
						} 
						
					}
					
					
					// Overlay - change homepage slider
					if( !empty($layout_type) && $layout_type=='overlay' ){
						$show_on_front  = get_option( 'show_on_front' );
						$page_on_front  = get_option( 'page_on_front' );
						$page           = get_page( $page_on_front );
						if( $show_on_front == 'page' && !empty($page) ){
							$post_meta = get_post_meta( $page_on_front, '_themestek_metabox_group', true );
							$post_meta['revslider'] = 'sliderdemo2';
							update_post_meta( $page_on_front, '_themestek_metabox_group', $post_meta );
						}
					}
					
					
					
					
					// Infostack - Change Topbar right content and remove phone number area
					if( !empty($layout_type) && $layout_type=='infostack' ){
						$theme_options = get_option('optico_theme_options');
						$theme_options['topbar_right_text'] = '[ts-social-links]';
						update_option('optico_theme_options', $theme_options);
					}
					
					
					
					
					
					// Update term count in admin section
					ts_update_term_count();
					flush_rewrite_rules(); // flush rewrite rule
					
					$answer['answer'] = 'finished';
					$answer['reload'] = 'yes';
					die( json_encode( $answer ) );
					
				break;
				
			}
			die;
		}
		
		
		
		/**
		 * Fetch and save image
		 **/
		function grab_image($url,$saveto){
			$ch = curl_init ($url);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
			$raw=curl_exec($ch);
			curl_close ($ch);
			if(file_exists($saveto)){
				unlink($saveto);
			}
			$fp = fopen($saveto,'x');
			fwrite($fp, $raw);
			fclose($fp);
		}

	} // END class

} // END if

if( !function_exists('ts_update_term_count') ){
function ts_update_term_count(){
	$get_taxonomies = get_taxonomies();
	foreach( $get_taxonomies as $taxonomy=>$taxonomy2 ){
		$terms = get_terms( $taxonomy, 'hide_empty=0' );
		$terms_array = array();
		foreach( $terms as $term ){
			$terms_array[] = $term->term_id;
		}
		if( !empty($terms_array) && count($terms_array)>0 ){
			$output = wp_update_term_count_now( $terms_array, $taxonomy );
		}
	}
}
}

// For AJAX callback
$themestek_optico_one_click_demo_setup = new themestek_optico_one_click_demo_setup;

