<?php
 
 
/**
 *  Version and directory
 */



/**
 *  Demo Content setup
 */
require_once THEMESTEK_OPTICO_DIR . 'demo-content-setup/one-click-demo/demo-content.php';



/**
 *  Translation
 */
function optico_demosetup_load_plugin_textdomain() {
	$domain = 'optico-demo-content-setup';
	$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
	if ( $loaded = load_textdomain( 'optico-demosetup', trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' ) ) {
		return $loaded;
	} else {
		load_plugin_textdomain( 'optico-demosetup', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}
}
add_action( 'init', 'optico_demosetup_load_plugin_textdomain' );



/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function optico_demosetup_load_textdomain() {
	load_plugin_textdomain( 'optico-demosetup', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'optico_demosetup_load_textdomain' );







function optico_demo_content_scripts_styles(){

	wp_enqueue_style(
		'ts-one-click-demo-style',
		plugin_dir_url( __FILE__ ) . 'style.css',
		time(),
		true
	);
	wp_enqueue_script(
		'ts-one-click-demo-set-js',
		plugin_dir_url( __FILE__ ) . 'functions.js',
		array( 'jquery' ),
		time(),
		true
	);
	


}
add_action( 'admin_enqueue_scripts', 'optico_demo_content_scripts_styles', 20 );



/**
 * html Output for the one click demo setup
 *
 * @since 1.0.0
 */
if( !function_exists('themestek_optico_one_click_html') ){
function themestek_optico_one_click_html() {
	?>
	
	
	
	
	<div class="themestek-demo-import-btn">
		<!--<a href="#TB_inline?height=300&width=content&inlineId=themestek-demo-import-form&modal=true" class="thickbox button button-primary"> Import Demo data </a>-->
		<a href="#" class="button button-primary ts-open-demo-box"> Import Demo data </a>
	</div>
	
	<div id="themestek-demo-import-form-w" style="display:none;">
	
		<div class="themestek-demo-import-form-bg-grey">
			<div id="themestek-demo-import-form">
				<div class="themestek-demo-import-close-w"><a href="#"><i class="fa fa-close"></i></a></div>
				<div id="themestek-demo-import-form-inner">
			
					<h2>Demo Importer</h2>
					
					<div class="ts-import-demo-boxes-w">
					
						<div class="import-demo-thumb-w import-demo-thumb-default">
							<div class="import-demo-thumb-img">
								<div class="import-demo-thumb-img-overlay" style="display:none;"><div class="import-demo-thumb-img-overlay-inner"><i class="fa fa-cog fa-spin"></i></div></div>
								<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/thumb-1.jpg" />
							</div>
							<div class="ts-import-demo-buttons">
								<a href="http://optico.themestek.com/" target="_blank" class="button ts-import-demo-preview-link"> <i class="fa fa-external-link"></i> Preview</a>
								<button href="#" class="button button-primary ts-import-demo-import-demo-link"> <i class="fa fa-check"></i> Import Demo</button>
							</div>
							<div class="ts-import-demo-conformation-w" style="display:none;">
								<div class="ts-import-demo-conformation">
									<span>Are you sure you want to setup demo content?</span> <br><br>
									<a href="#" class="button button-primary ts-import-demo-import-demo-do-process" data-demo="Classic"> <i class="fa fa-check"></i> Yes</a> &nbsp;
									<a href="#" class="button button-primary ts-import-demo-import-demo-no"> <i class="fa fa-close"></i> No</a>
								</div>
							</div>
						</div>
						
						<div class="import-demo-thumb-w import-demo-thumb-default">
							<div class="import-demo-thumb-img">
								<div class="import-demo-thumb-img-overlay" style="display:none;"><div class="import-demo-thumb-img-overlay-inner"><i class="fa fa-cog fa-spin"></i></div></div>
								<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/thumb-2.jpg" />
							</div>
							<div class="ts-import-demo-buttons">
								<a href="https://optico.themestek.com/demo1/" target="_blank" class="button ts-import-demo-preview-link"> <i class="fa fa-external-link"></i> Preview</a>
								<button href="#" class="button button-primary ts-import-demo-import-demo-link"> <i class="fa fa-check"></i> Import Demo</button>
							</div>
							<div class="ts-import-demo-conformation-w" style="display:none;">
								<div class="ts-import-demo-conformation">
									<span>Are you sure you want to setup demo content?</span> <br><br>
									<a href="#" class="button button-primary ts-import-demo-import-demo-do-process" data-demo="InfoStack"> <i class="fa fa-check"></i> Yes</a> &nbsp;
									<a href="#" class="button button-primary ts-import-demo-import-demo-no"> <i class="fa fa-close"></i> No</a>
								</div>
							</div>
						</div>
						
						<div class="import-demo-thumb-w import-demo-thumb-default">
							<div class="import-demo-thumb-img">
								<div class="import-demo-thumb-img-overlay" style="display:none;"><div class="import-demo-thumb-img-overlay-inner"><i class="fa fa-cog fa-spin"></i></div></div>
								<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/thumb-3.jpg" />
							</div>
							<div class="ts-import-demo-buttons">
								<a href="https://optico.themestek.com/demo2/" target="_blank" class="button ts-import-demo-preview-link"> <i class="fa fa-external-link"></i> Preview</a>
								<button href="#" class="button button-primary ts-import-demo-import-demo-link"> <i class="fa fa-check"></i> Import Demo</button>
							</div>
							<div class="ts-import-demo-conformation-w" style="display:none;">
								<div class="ts-import-demo-conformation">
									<span>Are you sure you want to setup demo content?</span> <br><br>
									<a href="#" class="button button-primary ts-import-demo-import-demo-do-process" data-demo="Overlay"> <i class="fa fa-check"></i> Yes</a> &nbsp;
									<a href="#" class="button button-primary ts-import-demo-import-demo-no"> <i class="fa fa-close"></i> No</a>
								</div>
							</div>
						</div>
						
						<div class="clear clr"></div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	
	
	
	<!--
	<div id="import-demo-data-results">
				
		<div class="import-demo-data-text-w">
		
			<div class="import-demo-data-layout">
				
				<div class="ts-import-demo-left">
					<div class="ts-import-demo-left-inner">
						
						<select id="import-layout-type" name="import-layout-type">
							<option value="Default">Default site</option>
							<option value="Overlay">Overlay Site</option>
							<option value="InfoStack">InfoStack Site</option>
						</select>
						
						<br><br><hr>
						
						<div class="import-demo-data-text">
						
							<strong><?php esc_attr_e('NOTE:', 'optico'); ?></strong>
							<?php esc_attr_e('This process may overwrite your existing content or settings. So please do this on fresh WordPress setup only.', 'optico'); ?>
							<br /><br />
							<?php esc_attr_e('Also if you already included demo data than this will add multiple menu links and you need to remove the repeated menu items by going to "Admin > Appearance > menus" section.', 'optico'); ?>
							
						</div>

						
					</div>
				</div>
				
				<div class="ts-import-demo-right">
					<span class="import-demo-thumb-w import-demo-thumb-default">
						<div class="ts-import-demo-preview-text">Preview:</div>
						<a href="http://optico.themestek.com/" target="_blank">
							<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/layout-default.png">
							<span class="ts-import-demo-link-text">View demo online</span>
						</a>
					</span>
					
					<span class="import-demo-thumb-w import-demo-thumb-infostack" style="display:none;">
						<div class="ts-import-demo-preview-text">Preview:</div>
						<a href="http://optico.themestek.com/optico-infostack/" target="_blank">
							<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/layout-infostack.png">
							<span class="ts-import-demo-link-text">View demo online</span>
						</a>
					</span>
					
					<span class="import-demo-thumb-w import-demo-thumb-overlay" style="display:none;">
						<div class="ts-import-demo-preview-text">Preview:</div>
						<a href="http://optico.themestek.com/optico-overlay/" target="_blank">
							<img src="<?php echo plugin_dir_url( __FILE__ ) ?>images/layout-overlay.png">
							<span class="ts-import-demo-link-text">View demo online</span>
						</a>
					</span>
					
					
				</div>
				
				<div class="clear clr"></div>
				
			</div>
		
			
			<br /><br />
			<input type="button" class="button button-primary" id="themestek_one_click_demo_content" value="<?php esc_attr_e('I agree, continue demo content setup', 'optico'); ?>" /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
			<a href="#" class="ts-one-click-error-close"><?php esc_attr_e('Cancel', 'optico' ); ?></a>
		</div>
	
	</div>
	-->
	
	<div class="clear"></div>
	
	<?php
}
}


