<?php
// [ts-servicebox]
if( !function_exists('themestek_sc_servicebox') ){
function themestek_sc_servicebox( $atts, $content=NULL ){
	
	$return = '';
	
	if( function_exists('vc_map') ){
		
		global $ts_sc_params_servicebox;
		$options_list = ts_create_options_list($ts_sc_params_servicebox);
		
		// This global variable will be used in template file for design
		global $ts_global_sbox_element_values;
		$ts_global_sbox_element_values = array();
		
		extract( shortcode_atts(
			$options_list
		, $atts ) );
		
		
		// $arr = get_defined_vars();
		
		/** ICON **/
		$icon_type_class = '';
		if( !empty($icon_type) && $icon_type=='text' ){
			$icon_html = '<div class="ts-sbox-icon-wrapper ts-sbox-icon-type-text">'.$small_text.'</div>';
			$icon_type_class = 'text';
		} else if( !empty($icon_type) && $icon_type=='none' ){
			$icon_html = '';
			$icon_type_class = 'none';
		} else {
			// We are calling this to add CSS file of the selected icon.
			do_shortcode('[ts-icon type="'.$i_type.'" icon_fontawesome="'.$i_icon_fontawesome.'" icon_linecons="'.$i_icon_linecons.'" icon_themify="'.$i_icon_themify.'" color="skincolor" align="left"]');
			
			// This is real icon code
			$icon_class   = ( !empty( ${'i_icon_'.$i_type} ) ) ? ${'i_icon_'.$i_type} : '' ;
			$icon_html = '<div class="ts-sbox-icon-wrapper"><i class="' . $icon_class . '"></i></div>';
			$icon_type_class = 'icon';
		}
		
		
		
		
		/** HEADING AND SUBHEADING ***/
		$add_button_sc = ( !empty($show_btn) && $show_btn=='yes' ) ? 'add_button="bottom" btn_style="text"' : 'add_button="no"' ;
		
		$ctaShortcode = '[ts-cta';
		foreach( $options_list as $key=>$val ){
			if( trim( ${$key} )!=''  ){
				$ctaShortcode .= ' '.$key.'="'.${$key}.'" ';
			}
		}
		$ctaShortcode .= ' '.$add_button_sc.' i_css_animation="" css="" css_animation=""]'.$content.'[/ts-cta]';
		$heading_html = do_shortcode($ctaShortcode);

		
		
		
		
		// storing in global varibales to be used in template file
		$ts_global_sbox_element_values['boxstyle']		= $boxstyle;
		$ts_global_sbox_element_values['icon_html']		= $icon_html;
		$ts_global_sbox_element_values['heading_html']	= $heading_html;
		$ts_global_sbox_element_values['main-class']	= 'ts-sbox-itype-'.$icon_type_class; // Extra field
		
		// Extra Class
		if( !empty($el_class) ){
			$ts_global_sbox_element_values['main-class'] .= ' '.esc_attr($el_class);
		}

		
		// calling template depending on the selected VIEW option
		ob_start();
		get_template_part('theme-parts/servicebox/servicebox', $boxstyle);
		$return = ob_get_contents();
		ob_end_clean();
	
		
		
		
		
		
	} else {
		$return .= '<!-- Visual Composer plugin not installed. Please install it to make this shortcode work. -->';
	}

	
	return $return;
}
}
add_shortcode( 'ts-servicebox', 'themestek_sc_servicebox' );

if( !function_exists('themestek_bg_only_from_css') ){
function themestek_bg_only_from_css( $css ){
	// Check if '{' charactor exists
	if( strpos($css,'{' )!=false ){
		$css = substr($css, strpos($css,'{' )+1 ); // returns "d"
		$css = str_replace('}','', $css );
		$new_css_array = explode(';',$css);
		$bgonly_css = '';
		foreach( $new_css_array as $css_line ){
			if( substr($css_line,0,10)=='background' ){
				$bgonly_css .= $css_line.';';
			}
		}
	}
	//var_dump($bgonly_css);
	return $bgonly_css;
}
}

if( !function_exists('themestek_check_if_bg_color_in_css') ){
function themestek_check_if_bg_color_in_css( $css ){
	$return = false;
	
	// Check if '{' charactor exists
	if( strpos($css,'{' )!=false ){
		$css = substr($css, strpos($css,'{' )+1 ); // returns "d"
		$css = str_replace('}','', $css );
		$new_css_array = explode(';',$css);
		foreach( $new_css_array as $css_line ){
			if( substr($css_line,0,11)=='background:' ){
				$css_line = explode(' ',$css_line);
				foreach($css_line as $line){
					if( substr($line,0,5)=='rgba(' || substr($line,0,5)=='#' ){
						$return = true;
					}
				}
			}
		}
	}
	
	return $return;
}
}